## Gen1Recomp 0.2.15 compatibility

Red, Blue, Yellow, Gold, and Silver are supported. Gold and Silver use the same Gen 2 randomizer systems, with edition-specific host data selected by Gen1Recomp.

# Universal Randomizer 1.3.4 — Gen 1–4 Complete Scope

### 1.3.3 / menu mini-sprite fix

Fixes the party/menu mini-sprites retaining the opaque chroma-key background from their source sheets. All 493 two-frame icons now have transparent backgrounds, so expanded species render as actual mini-sprites instead of colored squares. Verified in real 0.2.15 Red, Gold, and Silver party menus.

### 1.3.2 / Gen 2 expanded-starter runtime fix

Fixes the field-reported Gold/Silver case where a Gen 3/4 starter roll could still execute Elm's vanilla one-byte species operand, leaving Chikorita/Cyndaquil/Totodile visible in black and white. Expanded starter targets now temporarily bridge through the selected pedestal's cartridge index for `pokepic`, `cry`, `getmonname`, and `givepoke`, then restore the host definitions immediately. The chooser text is replaced independently of native-index availability. Real 0.2.15 runtime tests now open, preview, confirm, and receive all three balls in both Gold and Silver with expanded targets.

### 1.3.1 / Gen1Recomp 0.2.15 hotfix

This build fixes starter sets that could visibly retain vanilla starter species, restores full-color Oak/Elm starter previews on the current 0.2.15 host, and prevents randomizer menu/status text from drawing past the wide setup surface. See `TEST-REPORT-0.2.15-HOTFIX.txt` for the executed runtime checks.

This build deliberately stops at **Generation 4**. It combines the certified National Dex #001–493 content layer with an independent per-save battle-rules selector through Gen 4.

## Pokémon content

- NATIVE
- GEN 1 (#001–151)
- GEN 1–2 (#001–251)
- GEN 1–3 (#001–386)
- GEN 1–4 (#001–493)

All 493 species have front sprites, back sprites, party icons, species data, evolution references, and randomizer pool support. The selected Pokédex ceiling is used by starters, trainers, wild encounters, static/gift Pokémon, trades, evolutions, and SAFE validation.

## Battle rules selector

- RULESET: GEN 1
- RULESET: GEN 2
- RULESET: GEN 3
- RULESET: GEN 4

The ruleset is independent of the Pokédex pool, is committed with the seed, participates in the run fingerprint, restores on save load, and is locked for the seeded run so mechanics cannot be changed silently mid-run.

Core generation differences covered by the rules framework include host-native Gen 1/2 delegation where available, Gen 1 single-Special compatibility, split Sp. Atk/Sp. Def for Gen 2+, type-based physical/special behavior through Gen 3, move-specific physical/special categories for Gen 4, generation-aware type effectiveness, critical-hit handling, accuracy behavior, and damage variance.

## Scope lock

Generation 5+ Pokémon and a Gen 5 rules option are intentionally not exposed in this release. This keeps the project focused on a fully validated Gen 1–4 target.

## Runtime target

Release baseline: Gen1Recomp 0.2.15. Red/Blue/Yellow, Gold, and Silver are supported. Silver uses its own Gen1Recomp version identity and ROM-derived data while sharing the same Gen 2 randomizer/Elm/Random Start logic as Gold. The 0.2.15 compatibility pass verifies the canonical Silver ROM hash and confirms the shipped Gold/Silver import manifests have identical gameplay structure for the randomizer-relevant maps/constants, differing only in ROM SHA-1 and symbol addresses.

See `TEST-REPORT.txt` for the exact certification boundary and checks.


## WIP Save 4 validation change
SAFE seed validation is now single-pass: preflight first, then one selected seed is constructed and validated. The old synchronous multi-candidate whole-registry retry loop has been removed to prevent Android startup freezes.

## WIP Save 5 — Retryable validation + seed hints

- AUTO SAFE validation now performs exactly one bounded seed attempt per press.
- A failed AUTO attempt leaves every selected option intact and changes the button to VALIDATE AGAIN; pressing it rolls a new candidate and tries once more.
- Manual seeds remain exact and are never silently replaced.
- Every readable sign can surface one deterministic hint generated from the committed seed and finalized randomized world data.
- Sign hint quality is intentionally mixed: trash, medium, and strong.
- Paid answers are available from the Start menu for 5000 Poke Dollars. One answer is generated per purchase with a useful bias (15% trash / 45% medium / 40% strong).
- Purchased answers have no category picker. A valid hint is selected first; money is then deducted.
- Paid hint progression is saved so repeated purchases advance deterministically within the same seed.

## WIP Save 6 Android expanded-pool validation optimization
The expanded Pokédex validation path now caches the move and HM pools used by bulk Pokemon mutation instead of rebuilding those registries for every species/learnset entry. This checkpoint specifically targets the observed difference where NATIVE validates but larger G1-2/G1-3/G1-4 pools can appear frozen on Android.

## WIP10 — Generation-native sprite bridge

Expanded Pokémon no longer use the old generic normalized battler set. The active
sprite bridge now uses original-generation source presentation for the expanded
roster:

- #152-251: Pokémon Gold/GSC front/back art and menu-icon style.
- #252-386: Pokémon Emerald 64x64 front/back art.
- #387-493: Pokémon Platinum 80x80 front/back art.
- Battle contexts keep the original source canvas and use Gen1Recomp's grounded
  battle-scale controls instead of destructively resizing the source image.
- Summary/Pokédex/evolution-style contexts use compact 56x56 canvases generated
  from those same native pixels so larger GBA/DS sprites do not overlap the
  Game Boy UI.
- Shiny battle/UI variants are generated from the original game's shiny palette
  where the live sprite seam exposes a shiny Pokémon instance.
- Party icons are sourced from the matching generation and adapted only to the
  Gen1Recomp party-menu sheet size.

Gen 1 Pokémon remain owned by the native Red/Blue/Yellow host renderer; on Gold,
#001-251 remain owned by Gold's native renderer. This avoids replacing art the
running game already presents correctly.


## WIP Save 11 visual/audio policy
All Pokémon #001-386 now have at least Gen 3-era front/back battle art; #387-493 retain Platinum Gen 4 art. All #001-493 receive species-specific cry audio from the Platinum source set on every host.


## Save 12 visual correction
- Gen 3 is the minimum visual floor for #001-386 on every sprite surface.
- Gen 4 native art remains for #387-493.
- All replacement art is forced true-color so cartridge palette remaps cannot recolor it.
- Gen 1 native 2x back-sprite scaling is disabled for 64x64 Gen 3 backs.
- Upgraded party icons now apply to native Gen 1/2 species as well as expanded species.


## Release candidate additions

- Random Badges: VANILLA / SAFE / CHAOS. SAFE Random Start requires SAFE badges and validates badge + HM escape chains for isolated starts.
- Kanto Random Start excludes Pallet Town and Viridian City. Cinnabar supports both Surf/Soul Badge and Fly/Thunder Badge escape plans.
- Gold Random Start arms when Elm grants the starter and consumes on the first exterior warp; it is one-shot across save/load state.
- Random Start now seeds the blackout/whiteout respawn at that start location immediately; until a Pokémon Center is reached, wipes cannot send the player back to the bedroom/home spawn.
- Random Abilities: NORMAL / SAFE / CHAOS; abilities are active only under Gen 3/4 rules.
- **Random Natures toggle:** ON/OFF in Pokémon Settings. ON assigns all 25 Gen 3/4 natures with their correct stat modifiers; OFF disables nature assignment/stat modifiers. Natures remain inactive under Gen 1/2 rules.
- Wild Levels: -50% through +50% in 10% steps.
- Trainer AI and Boss AI: NORMAL / STRONG. STRONG improves move choice without reading future input; bosses use the stronger weighting.
- Wide 304x144 Recomp-native setup screens and Run Info/share-code coverage for the new settings.
