return function(mod)
  local function localModule(path)
    local src,err=mod:read(path)
    assert(src,err or (path.." missing"))
    local chunk,cerr=load(src,"@"..mod.path.."/"..path)
    assert(chunk,cerr)
    return chunk()
  end

  local Core=localModule("core.lua")
  local Expanded493=localModule("expanded493/install.lua")
  local Expansion=Expanded493.install(mod)
  local Adapters=localModule("adapters.lua")
  local RandomizerFactory=localModule("randomizer.lua")
  local Randomizer=RandomizerFactory(mod,Core,Adapters,Expansion)
  local RulesetFactory=localModule("rulesets.lua")
  local Rulesets=RulesetFactory(mod,Expansion)
  local UIFactory=localModule("ui.lua")
  local UI=UIFactory(mod,Core,Randomizer)

  mod.exports.adapters=Adapters
  mod.exports.expanded493=Expansion
  mod.exports.defaults=Randomizer.defaults
  mod.exports.normalizedConfig=Randomizer.normalizedConfig
  mod.exports.preflight=Randomizer.preflight
  mod.exports.pokedexCap=Randomizer.pokedexCap
  mod.exports.availablePokedexModes=Randomizer.availablePokedexModes
  mod.exports.poolSize=Randomizer.poolSize
  mod.exports.generate=Randomizer.generate
  -- Exposed for deterministic runtime/CI startup-flow probes. The in-game UI
  -- uses the same two functions one stage per input frame.
  mod.exports.beginGenerate=Randomizer.beginGenerate
  mod.exports.stepGenerate=Randomizer.stepGenerate
  mod.exports.commit=Randomizer.commit
  mod.exports.clear=Randomizer.clear
  mod.exports.active=Randomizer.active
  mod.exports.summary=Randomizer.summary
  mod.exports.runCode=Randomizer.runCode
  mod.exports.hintForSign=Randomizer.hintForSign
  mod.exports.buyHint=Randomizer.buyHint
  mod.exports.rulesets=Rulesets.PRESETS
  -- Internal bridge used by expanded move/item mechanics at runtime.
  mod.exports.urRulesetEngine=Rulesets

  Randomizer.installHooks()

  -- The setup is part of a new game's Oak/Elm opening on both generations.
  -- No seed is committed before this step: settings first, validation second,
  -- seed commit third. Cancelling continues as a vanilla game.
  mod.hooks:wrap("intro.oak_speech.build",function(nextFn,steps,speech)
    steps=nextFn(steps,speech)
    if type(steps)~="table" then return steps end
    local inserted={
      id="universal_randomizer_setup",
      kind="fn",
      run=function(sp,done)
        UI.openSetup(sp.game,function(randomized,active)
          if randomized and active then Rulesets.apply(sp.game,active.cfg) else Rulesets.clear(sp.game) end
          done()
        end)
      end,
    }
    -- Put setup at the very front of the Oak/Elm timeline. The OakSpeech
    -- screen may already own the background/music, but no Professor text or
    -- naming prompt is allowed to run until the randomizer has been chosen.
    -- This keeps New Game -> Randomizer Setup -> Oak/Elm introduction.
    table.insert(steps,1,inserted)
    return steps
  end)

  local function activateSaved(game,context)
    local ok,active,err=pcall(Randomizer.activateSaved,game)
    if not ok then
      mod.log:error("failed to %s saved randomizer seed: %s",context,tostring(active))
    elseif not active and err then
      mod.log:error("failed to %s saved randomizer seed: %s",context,tostring(err))
    end
  end

  mod.events:on("game.ready",function(ev)
    local game=ev and (ev.game or ev) or mod.game
    local okUI,errUI=pcall(Rulesets.installAbilityUI,game)
    if not okUI then mod.log:error("ability UI install failed: %s",tostring(errUI)) end
    if game then
      local ok,why=Randomizer.installGen1HardcodedBridges(game)
      if ok==false then mod.log:error("randomizer Gen 1 bridge unavailable: %s",tostring(why)) end
      local ok2,why2=Randomizer.installGen2EncounterBridges(game)
      if ok2==false then mod.log:error("randomizer Gen 2 encounter bridge unavailable: %s",tostring(why2)) end
    end
    if game and mod.save:get("seed",nil) then
      activateSaved(game,"activate")
      Rulesets.apply(game,mod.save:get("config",{}))
    end
  end)

  mod.events:on("save.loaded",function(ev)
    local game=(ev and ev.game) or mod.game
    if game and mod.save:get("seed",nil) then
      activateSaved(game,"rebuild")
      Rulesets.apply(game,mod.save:get("config",{}))
    end
  end)

  -- Deterministic seed hints belong on informational signs, never on arbitrary
  -- BGEVENT_READ scripts.  Gen 2 reports both ordinary town signs and things
  -- like Rocket switches as kind="sign"; opening our Hint screen immediately
  -- used to cover those progression scripts and could prevent the switch from
  -- receiving its YES/NO input.  Only pure text sign programs qualify, and the
  -- hint is deferred until the cartridge script has completed.
  local pendingSignHint = nil
  local SAFE_SIGN_STD = { PokecenterSignScript=true, MartSignScript=true }
  local function gen2HintableSign(game, target)
    local key=target and target.scriptKey
    local scripts=game and game.world and game.world.scripts
    local rows=key and scripts and scripts[key]
    if type(rows)~="table" or #rows~=1 then return false end
    local row=rows[1] or {}
    if row.op=="jumptext" then return true end
    return row.op=="jumpstd" and SAFE_SIGN_STD[tostring(row.std)]==true
  end

  mod.events:on("world.interacted",function(ev)
    if not ev then return end
    if ev.kind~="sign" then return end
    local active=Randomizer.active()
    if not active then return end
    local game=mod.game or active.game
    local target=ev.target
    if game and game.world and game.world.scripts then
      -- Gold/Silver: conservatively reject any stateful/branching bg event.
      if not gen2HintableSign(game,target) then return end
      local text,tier=Randomizer.hintForSign(ev.mapId,ev.x,ev.y)
      if text then
        pendingSignHint={text=text,tier=tier,scriptKey=target and target.scriptKey,mapId=ev.mapId}
      end
      return
    end
    -- Gen 1 already distinguishes its sign arm from progression interactions.
    local text,tier=Randomizer.hintForSign(ev.mapId,ev.x,ev.y)
    if text then UI.openHint(game,text,tier) end
  end)

  mod.events:on("script.ended",function(ev)
    local p=pendingSignHint
    if not p then return end
    local ctx=ev and ev.ctx
    if not ev.completed or not ctx or ctx.generation~=2 then return end
    if p.scriptKey and ctx.scriptKey~=p.scriptKey then return end
    pendingSignHint=nil
    local active=Randomizer.active()
    local game=mod.game or (active and active.game)
    if game then UI.openHint(game,p.text,p.tier) end
  end)

  mod.hooks:wrap("ui.start_menu.items",function(nextFn,game,items)
    local out=nextFn(game,items)
    if type(out)~="table" then return out end
    -- Gen 1 Menu rows use onSelect; Gold's list rows use value and its main
    -- START menu hook normalizes mod rows with activate when present.
    out=mod.ui.insertBefore(out,"SAVE",{
      label="BUY HINT 5000",
      onSelect=function() UI.openBuyHint(game) end,
    })
    return mod.ui.insertBefore(out,"SAVE",{
      label="RANDO INFO",
      -- Keep this as a callback-only row. Gold's Gen2 StartMenu deliberately
      -- dispatches hook-added rows through onSelect only when value is nil; a
      -- synthetic value falls through to Game2:openStartMenuItem and does
      -- nothing. The same callback-only shape is native to Gen 1 as well.
      onSelect=function() UI.openInfo(game) end,
    })
  end)
end
