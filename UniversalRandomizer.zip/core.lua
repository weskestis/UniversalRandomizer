local M = {}

local MOD32 = 4294967296

local function copy(v, seen)
  if type(v) ~= "table" then return v end
  seen = seen or {}
  if seen[v] then return seen[v] end
  local out = {}
  seen[v] = out
  for k, x in pairs(v) do out[copy(k, seen)] = copy(x, seen) end
  return out
end
M.copy = copy

function M.hash(text, seed)
  local h = tonumber(seed) or 2166136261
  text = tostring(text or "")
  for i = 1, #text do
    h = (h * 65599 + string.byte(text, i) + i * 17) % MOD32
  end
  if h == 0 then h = 1 end
  return h
end

function M.rng(seed)
  local state = (tonumber(seed) or 1) % MOD32
  if state == 0 then state = 1 end
  local R = {}
  function R:next32()
    state = (state * 1664525 + 1013904223) % MOD32
    return state
  end
  function R:int(lo, hi)
    if hi == nil then hi, lo = lo, 1 end
    lo, hi = math.floor(lo or 1), math.floor(hi or 1)
    if hi < lo then lo, hi = hi, lo end
    local span = hi - lo + 1
    if span <= 1 then return lo end
    return lo + (self:next32() % span)
  end
  function R:chance(percent)
    return self:int(1, 10000) <= math.floor((percent or 0) * 100)
  end
  function R:pick(list)
    if not list or #list == 0 then return nil end
    return list[self:int(1, #list)]
  end
  function R:shuffle(list)
    for i = #list, 2, -1 do
      local j = self:int(1, i)
      list[i], list[j] = list[j], list[i]
    end
    return list
  end
  return R
end

function M.sortedKeys(t, pred)
  local out = {}
  for k, v in pairs(t or {}) do
    if not pred or pred(k, v) then out[#out + 1] = k end
  end
  table.sort(out, function(a, b) return tostring(a) < tostring(b) end)
  return out
end

function M.tableHas(list, value)
  for _, v in ipairs(list or {}) do if v == value then return true end end
  return false
end

function M.unique(list)
  local seen, out = {}, {}
  for _, v in ipairs(list or {}) do
    if v ~= nil and not seen[v] then seen[v] = true; out[#out + 1] = v end
  end
  return out
end

function M.bst(def)
  local b = def and def.baseStats or {}
  local total = 0
  for _, v in pairs(b) do if type(v) == "number" then total = total + v end end
  return total
end

function M.statKeys(def)
  local b = def and def.baseStats or {}
  local preferred = { "hp", "attack", "defense", "speed", "special", "specialAttack", "specialDefense" }
  local out = {}
  for _, k in ipairs(preferred) do if type(b[k]) == "number" then out[#out + 1] = k end end
  return out
end

function M.redistributeStats(def, rng)
  local keys = M.statKeys(def)
  local bst = M.bst(def)
  local out = {}
  if #keys == 0 then return out end
  local order = {}
  for i = 1, #keys do order[i] = keys[i] end
  rng:shuffle(order)
  local remaining = bst
  for i, k in ipairs(order) do
    local left = #order - i
    local lo = math.max(1, remaining - 255 * left)
    local hi = math.min(255, remaining - left)
    if i == #order then lo, hi = remaining, remaining end
    local v = rng:int(lo, hi)
    out[k] = v
    remaining = remaining - v
  end
  return out
end

function M.fingerprint(seed, cfg, version)
  local keys = M.sortedKeys(cfg)
  local s = tostring(version or "?") .. "|" .. tostring(seed or 0)
  for _, k in ipairs(keys) do s = s .. "|" .. k .. "=" .. tostring(cfg[k]) end
  local h = M.hash(s, 0x13579b)
  return ("%08X"):format(h % MOD32)
end

function M.resolveIndexedId(table_, value)
  if type(value) == "string" then return value end
  if type(value) ~= "number" then return nil end
  for id, def in pairs(table_ or {}) do
    if type(def) == "table" and def.index == value then return id end
  end
  return nil
end

function M.deepcopyInto(dst, src)
  for k in pairs(dst or {}) do dst[k] = nil end
  for k, v in pairs(src or {}) do dst[k] = copy(v) end
  return dst
end

return M
