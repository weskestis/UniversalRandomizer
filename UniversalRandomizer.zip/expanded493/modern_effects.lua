-- Gen 3/4 battle-effect compatibility layer for expanded #001-493 moves.
-- The Gen 1 and Gen 2 engines expose the same mod move-effect registry but
-- dispatch run() with different signatures.  Every source effect is registered
-- here and normalized onto one context so Gold never loses damage merely
-- because a modern effect supplied a handler.
return function(mod, src)
  local reg=mod.content.move_effects
  if not reg then return {registered=0,total=0,explicit=0,passive=0} end

  local meta={}
  for _,m in ipairs(src.moves or {}) do
    local e=m.effect
    if e then
      local x=meta[e] or {powered=false,maxPower=0,chance=0,moves={}}
      local p=tonumber(m.power) or 0
      x.powered=x.powered or p>0; x.maxPower=math.max(x.maxPower,p)
      x.chance=math.max(x.chance,tonumber(m.chance) or 0)
      x.moves[#x.moves+1]=m
      meta[e]=x
    end
  end

  local statusG1={sleep='SLP',poison='PSN',burn='BRN',freeze='FRZ',paralyze='PAR'}
  local statusG2={sleep='sleep',poison='poison',burn='burn',freeze='freeze',paralyze='paralyze'}
  local function ruleset()
    return mod.exports and mod.exports.urRulesetEngine
  end
  local function activeGen()
    local r=ruleset(); return r and r.activeGeneration and r.activeGeneration() or 0
  end
  local function abilityOf(ctx,b)
    local r=ruleset(); local game=(ctx and ctx.battle and ctx.battle.game) or mod.game
    return r and r.abilityFor and r.abilityFor(game,b) or nil
  end
  local function effectiveWeather(ctx)
    local r=ruleset(); local game=(ctx and ctx.battle and ctx.battle.game) or mod.game
    if r and r.effectiveWeather then return r.effectiveWeather(game,ctx and ctx.battle) end
    local f=ctx and (ctx.field or (ctx.battle and ctx.battle.field)); return f and f.weather
  end
  local function heldEffect(ctx,b)
    local r=ruleset(); local game=(ctx and ctx.battle and ctx.battle.game) or mod.game
    if r and r.heldEffect then return r.heldEffect(game,b) end
  end
  local function consumeHeld(ctx,b)
    local r=ruleset(); local game=(ctx and ctx.battle and ctx.battle.game) or mod.game
    if r and r.consumeHeld then return r.consumeHeld(game,b) end
  end
  local function monOf(b) return (b and b.mon) or b end
  local function hpMax(m) return (m and ((m.stats and m.stats.hp) or m.maxHp)) or 1 end
  local function rand(ctx,a,b)
    -- Gen 2 Battle:roller() is a one-argument BattleRandom-style function that
    -- returns 0..n-1, while Gen 1/mod contexts may expose an a,b RNG.  Calling
    -- the Gen 2 roller as rng(a,b) silently ignored b; rng(1,8) therefore
    -- returned 0 and multi-hit lookup produced nil, crashing a numeric for-loop.
    if ctx.rng then
      if ctx._gold and b ~= nil then
        local span=math.max(1,(tonumber(b) or 1)-(tonumber(a) or 1)+1)
        local ok,v=pcall(ctx.rng,span)
        if ok and type(v)=='number' then
          v=math.floor(v)
          if v<0 then v=0 elseif v>=span then v=span-1 end
          return (tonumber(a) or 1)+v
        end
      else
        local ok,v=pcall(ctx.rng,a,b)
        if ok and type(v)=='number' then
          if b ~= nil then
            v=math.floor(v)
            local lo,hi=tonumber(a) or 1,tonumber(b) or tonumber(a) or 1
            if v<lo then v=lo elseif v>hi then v=hi end
          end
          return v
        end
      end
    end
    if ctx.battle and ctx.battle.random then
      local r=ctx.battle.random
      if type(r)=='function' then
        local ok,v=pcall(r,a,b)
        if ok and type(v)=='number' then
          if b ~= nil then
            v=math.floor(v)
            local lo,hi=tonumber(a) or 1,tonumber(b) or tonumber(a) or 1
            if v<lo then v=lo elseif v>hi then v=hi end
          end
          return v
        end
      end
    end
    return math.random(a,b)
  end
  local function chance(ctx,p)
    p=tonumber(p) or 100; if p<=0 then p=100 end
    local gen=activeGen()
    if gen>=3 then
      local ua=abilityOf(ctx,ctx.user); local ta=abilityOf(ctx,ctx.target)
      if ua=='ABILITY_SERENE_GRACE' and p<100 then p=math.min(100,p*2) end
      if ta=='ABILITY_SHIELD_DUST' and p<100 and ctx.move and (tonumber(ctx.move.power) or 0)>0 then return false end
    end
    return p>=100 or rand(ctx,1,100)<=p
  end
  local function msg(ctx,text)
    if not text then return end
    if ctx.say then pcall(ctx.say,text)
    elseif ctx.battle and ctx.battle.emit then pcall(ctx.battle.emit,ctx.battle,{kind='message',text=text}) end
  end
  local function side(ctx,b)
    if ctx.side then local ok,v=pcall(ctx.side,b); if ok then return v end end
    if ctx.battle and ctx.battle.sideOf then local ok,v=pcall(ctx.battle.sideOf,ctx.battle,monOf(b)); if ok then return v end end
  end
  local function stage(ctx,b,stat,delta)
    if not b then return end
    local gen=activeGen(); local ab=gen>=3 and abilityOf(ctx,b) or nil
    if delta<0 and b==ctx.target and b~=ctx.user then
      if ab=='ABILITY_CLEAR_BODY' or ab=='ABILITY_WHITE_SMOKE' or (ab=='ABILITY_HYPER_CUTTER' and stat=='attack') or (ab=='ABILITY_KEEN_EYE' and stat=='accuracy') then
        msg(ctx,(tostring(ab):gsub('ABILITY_',''):gsub('_',' '))..' prevented the stat drop!')
        return
      end
    end
    if ab=='ABILITY_SIMPLE' then delta=delta*2 end
    if delta<0 and heldEffect(ctx,b)=='HOLD_EFFECT_STATDOWN_RESTORE' then consumeHeld(ctx,b); return end
    if ctx.changeStage then pcall(ctx.changeStage,b,stat,delta,b==ctx.target); return end
    if ctx.battle and ctx.battle.changeStage then pcall(ctx.battle.changeStage,ctx.battle,monOf(b),stat,delta); return end
    b.stages=b.stages or {}; b.stages[stat]=math.max(-6,math.min(6,(b.stages[stat] or 0)+delta))
  end
  local function inflict(ctx,b,name)
    local m=monOf(b); if not m or (m.hp or 0)<=0 then return false end
    local gen=activeGen(); local ab=gen>=3 and abilityOf(ctx,b) or nil
    local w=effectiveWeather(ctx)
    if (ab=='ABILITY_LIMBER' and name=='paralyze') or ((ab=='ABILITY_INSOMNIA' or ab=='ABILITY_VITAL_SPIRIT') and name=='sleep') or (ab=='ABILITY_IMMUNITY' and name=='poison') or (ab=='ABILITY_WATER_VEIL' and name=='burn') or (ab=='ABILITY_MAGMA_ARMOR' and name=='freeze') or (ab=='ABILITY_LEAF_GUARD' and w=='sun') then
      msg(ctx,(tostring(ab):gsub('ABILITY_',''):gsub('_',' '))..' prevented the status!')
      return false
    end
    if ctx.inflict then pcall(ctx.inflict,b,statusG1[name] or name,{}); return true end
    if ctx.battle and ctx.battle.applyStatus then return ctx.battle:applyStatus(m,statusG2[name] or name,monOf(ctx.user)) end
    if not m.status then m.status=statusG1[name] or name; return true end
    return false
  end
  local function heal(ctx,b,n)
    local m=monOf(b); if not m then return end
    n=math.max(1,math.floor(n or 1))
    if ctx.battle and ctx._gold and ctx.battle.heal then ctx.battle:heal(m,n); return end
    m.hp=math.min(hpMax(m),(m.hp or 0)+n)
  end
  local function hurt(ctx,b,n)
    local m=monOf(b); if not m then return 0 end
    n=math.max(1,math.floor(n or 1))
    if ctx.damage then local ok,v=pcall(ctx.damage,b,n); if ok then return v or n end end
    if ctx.battle and ctx._gold and ctx.battle.dealDamage then return ctx.battle:dealDamage(monOf(ctx.user),m,n,{move=ctx.move,moveId=ctx.move and ctx.move.id}) end
    local before=m.hp or 0; m.hp=math.max(0,before-n); return before-m.hp
  end
  local function doGoldDamage(ctx,powerOverride)
    if not ctx._gold or not ctx.battle or not ctx.battle.hitOnce then return 0 end
    local def=ctx.move
    if not def or (tonumber(def.power) or 0)<=0 then return 0 end
    local opts={moveId=ctx.moveId or def.id}
    if powerOverride then opts.power=powerOverride end
    local mh=def.multiHit
    local hits=1
    if type(mh)=='number' then hits=mh
    elseif type(mh)=='table' and #mh>0 then hits=mh[rand(ctx,1,#mh)] or 1 end
    local total=0
    for _=1,hits do
      if (monOf(ctx.target).hp or 0)<=0 then break end
      total=total+(ctx.battle:hitOnce(monOf(ctx.user),monOf(ctx.target),def,opts) or 0)
    end
    ctx.totalDealt=total; return total
  end

  local function normalized(...)
    if select('#',...)==1 and type((...))=='table' and (...).battle then
      local c=(...); c._gold=false; c.moveId=c.moveId or (c.move and c.move.id); return c
    end
    local battle,user,target,def,moveId,sureHit=...
    return {battle=battle,user=user,target=target,move=def,moveId=moveId or (def and def.id),sureHit=sureHit,_gold=true,
      field=battle and (battle.field or battle),rng=battle and battle.roller and battle:roller() or nil}
  end

  local statTokens={ATK='attack',DEF='defense',SPEED='speed',SPD='speed',SP_ATK='specialAttack',SP_DEF='specialDefense',ACC='accuracy',EVA='evasion'}
  local function statFrom(e)
    if e:find('SP_ATK') then return 'specialAttack' end
    if e:find('SP_DEF') then return 'specialDefense' end
    for k,v in pairs(statTokens) do if e:find('_'..k..'_') or e:match('_'..k..'$') then return v end end
  end
  local function genericStage(e,ctx)
    local st=statFrom(e); if not st then return false end
    local down=e:find('DOWN') or e:find('LOWER')
    local up=e:find('_UP') or e:find('RAISE')
    if not down and not up then return false end
    local n=(e:find('_2') and 2 or 1)*(down and -1 or 1)
    local selfTarget=(up and not e:find('_HIT')) or e:find('OWN_') or e:find('USER_')
    stage(ctx,selfTarget and ctx.user or ctx.target,st,n); return true
  end

  local SPECIAL_DAMAGE={
    BATTLE_EFFECT_20_DAMAGE_FLAT=true,BATTLE_EFFECT_40_DAMAGE_FLAT=true,
    BATTLE_EFFECT_LEVEL_DAMAGE_FLAT=true,BATTLE_EFFECT_RANDOM_DAMAGE_1_TO_150_LEVEL=true,
    BATTLE_EFFECT_PSYWAVE=true,BATTLE_EFFECT_HALVE_HP=true,BATTLE_EFFECT_SET_HP_EQUAL_TO_USER=true,
    BATTLE_EFFECT_COUNTER=true,BATTLE_EFFECT_MIRROR_COAT=true,BATTLE_EFFECT_METAL_BURST=true,
    BATTLE_EFFECT_ONE_HIT_KO=true,
  }
  local PRIMARY_POWER={
    BATTLE_EFFECT_BIDE=true,BATTLE_EFFECT_BEAT_UP=true,BATTLE_EFFECT_FLING=true,
    BATTLE_EFFECT_NATURAL_GIFT=true,BATTLE_EFFECT_SPIT_UP=true,
    BATTLE_EFFECT_HIT_IN_3_TURNS=true,BATTLE_EFFECT_HIT_LAST_WHIFF_IF_HIT=true,
    BATTLE_EFFECT_MULTI_HIT=true,BATTLE_EFFECT_POISON_MULTI_HIT=true,
  }

  local explicit,passive=0,0
  local function execute(e,ctx,m)
    local p=(m and m.chance) or 100
    local gen=activeGen()
    local ua=gen>=3 and abilityOf(ctx,ctx.user) or nil
    local ta=gen>=3 and abilityOf(ctx,ctx.target) or nil
    local moveId=tostring(ctx.moveId or (ctx.move and ctx.move.id) or ''):upper()
    if gen>=3 and (moveId=='SELF_DESTRUCT' or moveId=='EXPLOSION') and (ua=='ABILITY_DAMP' or ta=='ABILITY_DAMP') then
      msg(ctx,'DAMP prevented the explosion!')
      return {}
    end
    if ua=='ABILITY_TRUANT' and ctx.user and ctx.user.urTruantLoaf then
      msg(ctx,'TRUANT made it loaf around!')
      return {}
    end
    -- Gold's custom move-effect run replaces its normal damage path. Restore
    -- ordinary damage first for powered secondary/full effects; cross-gen
    -- rulesets still apply because hitOnce routes through battle.damage.
    if ctx._gold and m and m.powered and not SPECIAL_DAMAGE[e] and not PRIMARY_POWER[e] then doGoldDamage(ctx) end

    if genericStage(e,ctx) then return {} end
    if e=='BATTLE_EFFECT_HIT' or e=='BATTLE_EFFECT_DO_NOTHING' or e=='BATTLE_EFFECT_PRIORITY_1' or e=='BATTLE_EFFECT_HIGH_CRITICAL' or e=='BATTLE_EFFECT_BYPASS_ACCURACY' or e=='BATTLE_EFFECT_PRIORITY_NEG_1_BYPASS_ACCURACY' then return {} end

    -- Major status families.
    if e=='BATTLE_EFFECT_STATUS_SLEEP' or e=='BATTLE_EFFECT_STATUS_SLEEP_NEXT_TURN' then inflict(ctx,ctx.target,'sleep'); return {} end
    if e=='BATTLE_EFFECT_STATUS_POISON' then inflict(ctx,ctx.target,'poison'); return {} end
    if e=='BATTLE_EFFECT_STATUS_BADLY_POISON' then if inflict(ctx,ctx.target,'poison') then monOf(ctx.target).toxicCounter=1 end; return {} end
    if e=='BATTLE_EFFECT_STATUS_BURN' then inflict(ctx,ctx.target,'burn'); return {} end
    if e=='BATTLE_EFFECT_STATUS_PARALYZE' then inflict(ctx,ctx.target,'paralyze'); return {} end
    if e=='BATTLE_EFFECT_STATUS_CONFUSE' then if ta~='ABILITY_OWN_TEMPO' then ctx.target.confused=rand(ctx,2,5) else msg(ctx,'OWN TEMPO prevented confusion!') end; return {} end
    if e=='BATTLE_EFFECT_STATUS_LEECH_SEED' then ctx.target.leechSeeded=true; return {} end
    if e=='BATTLE_EFFECT_STATUS_NIGHTMARE' then ctx.target.nightmare=true; return {} end
    if e:find('POISON') and e:find('_HIT') then if chance(ctx,p) then inflict(ctx,ctx.target,'poison') end; return {} end
    if e:find('BURN') and e:find('_HIT') then if chance(ctx,p) then inflict(ctx,ctx.target,'burn') end; return {} end
    if e:find('FREEZE') and e:find('_HIT') then if chance(ctx,p) then inflict(ctx,ctx.target,'freeze') end; return {} end
    if e:find('PARALYZE') and e:find('_HIT') then if chance(ctx,p) then inflict(ctx,ctx.target,'paralyze') end; return {} end
    if e:find('CONFUSE') and e:find('_HIT') then if chance(ctx,p) and ta~='ABILITY_OWN_TEMPO' then ctx.target.confused=rand(ctx,2,5) end; return {} end
    if e:find('FLINCH') then
      if chance(ctx,p>0 and p or 30) then
        if ta=='ABILITY_INNER_FOCUS' then msg(ctx,'INNER FOCUS prevented flinching!')
        else
          ctx.target.flinched=true
          if ta=='ABILITY_STEADFAST' then stage(ctx,ctx.target,'speed',1) end
        end
      end
      return {}
    end

    if e=='BATTLE_EFFECT_MULTI_HIT' or e=='BATTLE_EFFECT_POISON_MULTI_HIT' then
      if ctx._gold and ctx.battle and ctx.battle.hitOnce and ctx.move then
        local hits=(ua=='ABILITY_SKILL_LINK') and 5 or ({2,2,2,3,3,3,4,5})[rand(ctx,1,8)]
        local total=0
        for _=1,hits do
          if (monOf(ctx.target).hp or 0)<=0 then break end
          total=total+(ctx.battle:hitOnce(monOf(ctx.user),monOf(ctx.target),ctx.move,{moveId=ctx.moveId}) or 0)
        end
        ctx.totalDealt=total
        if e=='BATTLE_EFFECT_POISON_MULTI_HIT' and chance(ctx,p) then inflict(ctx,ctx.target,'poison') end
      end
      return {}
    end

    -- Fixed/special damage effects.
    if e=='BATTLE_EFFECT_20_DAMAGE_FLAT' then if ctx._gold then hurt(ctx,ctx.target,20) end; return {} end
    if e=='BATTLE_EFFECT_40_DAMAGE_FLAT' then if ctx._gold then hurt(ctx,ctx.target,40) end; return {} end
    if e=='BATTLE_EFFECT_LEVEL_DAMAGE_FLAT' then if ctx._gold then hurt(ctx,ctx.target,monOf(ctx.user).level or 1) end; return {} end
    if e=='BATTLE_EFFECT_RANDOM_DAMAGE_1_TO_150_LEVEL' then if ctx._gold then hurt(ctx,ctx.target,math.max(1,math.floor((monOf(ctx.user).level or 1)*rand(ctx,50,150)/100))) end; return {} end
    if e=='BATTLE_EFFECT_PSYWAVE' then if ctx._gold then hurt(ctx,ctx.target,math.max(1,math.floor((monOf(ctx.user).level or 1)*rand(ctx,5,15)/10))) end; return {} end
    if e=='BATTLE_EFFECT_HALVE_HP' then if ctx._gold then hurt(ctx,ctx.target,math.max(1,math.floor((monOf(ctx.target).hp or 1)/2))) end; return {} end
    if e=='BATTLE_EFFECT_SET_HP_EQUAL_TO_USER' then if ctx._gold then local d=(monOf(ctx.target).hp or 1)-(monOf(ctx.user).hp or 1); if d>0 then hurt(ctx,ctx.target,d) end end; return {} end
    if e=='BATTLE_EFFECT_ONE_HIT_KO' then
      if ta=='ABILITY_STURDY' then msg(ctx,'STURDY blocked the one-hit KO!'); return {} end
      if ctx._gold then hurt(ctx,ctx.target,monOf(ctx.target).hp or 1) end; return {}
    end

    -- Recovery/recoil/drain.
    if e=='BATTLE_EFFECT_RESTORE_HALF_HP' or e:find('HEAL_HALF') then heal(ctx,ctx.user,math.floor(hpMax(monOf(ctx.user))/2)); return {} end
    if e=='BATTLE_EFFECT_HEAL_HALF_MORE_IN_SUN' then local f=ctx.field or {}; local frac=f.weather=='sun' and 2/3 or (f.weather=='rain' or f.weather=='hail' or f.weather=='sand') and 1/4 or 1/2; heal(ctx,ctx.user,math.floor(hpMax(monOf(ctx.user))*frac)); return {} end
    if e=='BATTLE_EFFECT_REST' then local u=monOf(ctx.user); heal(ctx,ctx.user,hpMax(u)); u.status=nil; inflict(ctx,ctx.user,'sleep'); return {} end
    if e:find('RECOVER_HALF_DAMAGE_DEALT') or e=='BATTLE_EFFECT_RECOVER_DAMAGE_SLEEP' then
      local n=math.floor((ctx.totalDealt or 0)/2)
      local he=heldEffect(ctx,ctx.user); if he=='HOLD_EFFECT_LEECH_BOOST' then n=math.floor(n*13/10) end
      if ta=='ABILITY_LIQUID_OOZE' then hurt(ctx,ctx.user,n); msg(ctx,'LIQUID OOZE hurt the attacker!') else heal(ctx,ctx.user,n) end
      return {}
    end
    if e:find('RECOIL_HALF') then if ua~='ABILITY_ROCK_HEAD' then hurt(ctx,ctx.user,math.floor((ctx.totalDealt or 1)/2)) end; return {} end
    if e:find('RECOIL_THIRD') or e:find('RECOIL_BURN') or e:find('RECOIL_PARALYZE') then if ua~='ABILITY_ROCK_HEAD' then hurt(ctx,ctx.user,math.floor((ctx.totalDealt or 1)/3)) end; return {} end
    if e:find('RECOIL_QUARTER') then if ua~='ABILITY_ROCK_HEAD' then hurt(ctx,ctx.user,math.floor((ctx.totalDealt or 1)/4)) end; return {} end
    if e=='BATTLE_EFFECT_CRASH_ON_MISS' then return {} end

    -- Screens, weather, hazards, rooms and field state.
    local f=ctx.field or (ctx.battle and ctx.battle.field) or ctx.battle
    if e=='BATTLE_EFFECT_SET_REFLECT' then local s=side(ctx,ctx.user); local he=heldEffect(ctx,ctx.user); local turns=he=='HOLD_EFFECT_EXTEND_SCREENS' and 8 or 5; if type(s)=='table' then s.reflect=turns elseif ctx.battle then ctx.battle.urReflect=ctx.battle.urReflect or {}; ctx.battle.urReflect[s]=turns end; return {} end
    if e=='BATTLE_EFFECT_SET_LIGHT_SCREEN' then local s=side(ctx,ctx.user); local he=heldEffect(ctx,ctx.user); local turns=he=='HOLD_EFFECT_EXTEND_SCREENS' and 8 or 5; if type(s)=='table' then s.lightScreen=turns elseif ctx.battle then ctx.battle.urLightScreen=ctx.battle.urLightScreen or {}; ctx.battle.urLightScreen[s]=turns end; return {} end
    if e=='BATTLE_EFFECT_REMOVE_SCREENS' or e=='BATTLE_EFFECT_REMOVE_HAZARDS_SCREENS_EVA_DOWN' then if ctx.battle then ctx.battle.urReflect={}; ctx.battle.urLightScreen={} end; return {} end
    if e=='BATTLE_EFFECT_PROTECT' then ctx.user.protect=true; return {} end
    if e=='BATTLE_EFFECT_REMOVE_PROTECT' then ctx.target.protect=nil; return {} end
    if e=='BATTLE_EFFECT_PREVENT_ESCAPE' then ctx.target.trapped=true; return {} end
    if e=='BATTLE_EFFECT_BIND_HIT' or e=='BATTLE_EFFECT_WHIRLPOOL' then ctx.target.trappingTurns=(heldEffect(ctx,ctx.user)=='HOLD_EFFECT_EXTEND_TRAPPING') and 5 or rand(ctx,2,5); return {} end
    if e=='BATTLE_EFFECT_SET_SPIKES' then ctx.battle.urSpikes=ctx.battle.urSpikes or {}; local s=side(ctx,ctx.target); ctx.battle.urSpikes[s]=math.min(3,(ctx.battle.urSpikes[s] or 0)+1); return {} end
    if e=='BATTLE_EFFECT_TOXIC_SPIKES' then ctx.battle.urToxicSpikes=ctx.battle.urToxicSpikes or {}; local s=side(ctx,ctx.target); ctx.battle.urToxicSpikes[s]=math.min(2,(ctx.battle.urToxicSpikes[s] or 0)+1); return {} end
    if e=='BATTLE_EFFECT_STEALTH_ROCK' then ctx.battle.urStealthRock=ctx.battle.urStealthRock or {}; ctx.battle.urStealthRock[side(ctx,ctx.target)]=true; return {} end
    if e=='BATTLE_EFFECT_REMOVE_HAZARDS_AND_BINDING' then ctx.target.trappingTurns=nil; if ctx.battle then ctx.battle.urSpikes={}; ctx.battle.urToxicSpikes={}; ctx.battle.urStealthRock={} end; return {} end
    if e=='BATTLE_EFFECT_WEATHER_RAIN' then f.weather='rain'; f.weatherTurns=(heldEffect(ctx,ctx.user)=='HOLD_EFFECT_EXTEND_RAIN') and 8 or 5; return {} end
    if e=='BATTLE_EFFECT_WEATHER_SUN' then f.weather='sun'; f.weatherTurns=(heldEffect(ctx,ctx.user)=='HOLD_EFFECT_EXTEND_SUN') and 8 or 5; return {} end
    if e=='BATTLE_EFFECT_WEATHER_SANDSTORM' then f.weather='sand'; f.weatherTurns=(heldEffect(ctx,ctx.user)=='HOLD_EFFECT_EXTEND_SANDSTORM') and 8 or 5; return {} end
    if e=='BATTLE_EFFECT_WEATHER_HAIL' then f.weather='hail'; f.weatherTurns=(heldEffect(ctx,ctx.user)=='HOLD_EFFECT_EXTEND_HAIL') and 8 or 5; return {} end
    if e=='BATTLE_EFFECT_TRICK_ROOM' then f.trickRoom=5; return {} end
    if e=='BATTLE_EFFECT_GRAVITY' then f.gravity=5; return {} end
    if e=='BATTLE_EFFECT_GIVE_GROUND_IMMUNITY' then ctx.user.magnetRise=5; return {} end
    if e=='BATTLE_EFFECT_GROUND_TRAP_USER_CONTINUOUS_HEAL' then ctx.user.ingrain=true; return {} end

    -- Volatile move-control state.
    if e=='BATTLE_EFFECT_DISABLE' then ctx.target.disabledMove=ctx.target.lastMove; ctx.target.disableTurns=rand(ctx,4,7); return {} end
    if e=='BATTLE_EFFECT_ENCORE' then ctx.target.encoreMove=ctx.target.lastMove; ctx.target.encoreTurns=rand(ctx,4,8); return {} end
    if e=='BATTLE_EFFECT_TAUNT' then ctx.target.tauntTurns=3; return {} end
    if e=='BATTLE_EFFECT_TORMENT' then ctx.target.torment=true; return {} end
    if e=='BATTLE_EFFECT_MAKE_SHARED_MOVES_UNUSEABLE' then ctx.target.imprisonedBy=ctx.user; return {} end
    if e=='BATTLE_EFFECT_PREVENT_HEALING' then ctx.target.healBlocked=5; return {} end
    if e=='BATTLE_EFFECT_PREVENT_ITEM_USE' then ctx.target.embargoTurns=5; return {} end
    if e=='BATTLE_EFFECT_PREVENT_STATUS' then local s=side(ctx,ctx.user); ctx.battle.urSafeguard=ctx.battle.urSafeguard or {}; ctx.battle.urSafeguard[s]=5; return {} end
    if e=='BATTLE_EFFECT_PREVENT_CRITS' then ctx.target.luckyChant=5; return {} end
    if e=='BATTLE_EFFECT_PREVENT_STAT_REDUCTION' then ctx.user.mistTurns=5; return {} end
    if e=='BATTLE_EFFECT_NEXT_ATTACK_ALWAYS_HITS' then ctx.target.lockOnBy=ctx.user; return {} end
    if e=='BATTLE_EFFECT_MAKE_GLOBAL_TARGET' then ctx.target.followMe=true; return {} end
    if e=='BATTLE_EFFECT_INFATUATE' then
      if ta=='ABILITY_OBLIVIOUS' then msg(ctx,'OBLIVIOUS prevented infatuation!')
      else
        ctx.target.infatuatedWith=ctx.user
        if heldEffect(ctx,ctx.target)=='HOLD_EFFECT_RECIPROCATE_INFAT' then ctx.user.infatuatedWith=ctx.target end
      end
      return {}
    end
    if e=='BATTLE_EFFECT_FORESIGHT' or e=='BATTLE_EFFECT_IGNORE_EVATION_REMOVE_DARK_IMMUNE' then ctx.target.foresight=true; return {} end
    if e=='BATTLE_EFFECT_CRIT_UP_2' then ctx.user.focusEnergy=true; return {} end
    if e=='BATTLE_EFFECT_DOUBLE_SPEED_3_TURNS' then ctx.user.tailwindTurns=3; return {} end

    -- Stat/state exchange and copying.
    if e=='BATTLE_EFFECT_RESET_STAT_CHANGES' then ctx.user.stages={}; ctx.target.stages={}; return {} end
    if e=='BATTLE_EFFECT_COPY_STAT_CHANGES' then ctx.user.stages={}; for k,v in pairs(ctx.target.stages or {}) do ctx.user.stages[k]=v end; return {} end
    if e=='BATTLE_EFFECT_SWAP_STAT_CHANGES' then ctx.user.stages,ctx.target.stages=ctx.target.stages or {},ctx.user.stages or {}; return {} end
    if e=='BATTLE_EFFECT_SWAP_ATK_SP_ATK_STAT_CHANGES' then local s=ctx.user.stages or {}; s.attack,s.specialAttack=s.specialAttack or 0,s.attack or 0; ctx.user.stages=s; return {} end
    if e=='BATTLE_EFFECT_SWAP_DEF_SP_DEF_STAT_CHANGES' then local s=ctx.user.stages or {}; s.defense,s.specialDefense=s.specialDefense or 0,s.defense or 0; ctx.user.stages=s; return {} end
    if e=='BATTLE_EFFECT_SWAP_ATK_DEF' then local u=monOf(ctx.user); if u and u.stats then u.stats.attack,u.stats.defense=u.stats.defense,u.stats.attack end; return {} end
    if e=='BATTLE_EFFECT_SET_SUBSTITUTE' then local u=monOf(ctx.user); local cost=math.max(1,math.floor(hpMax(u)/4)); if (u.hp or 0)>cost then u.hp=u.hp-cost; ctx.user.substituteHP=cost end; return {} end
    if e=='BATTLE_EFFECT_SURVIVE_WITH_1_HP' or e=='BATTLE_EFFECT_LEAVE_WITH_1_HP' then ctx.user.endure=true; return {} end
    if e=='BATTLE_EFFECT_MAX_ATK_LOSE_HALF_MAX_HP' then local u=monOf(ctx.user); if (u.hp or 0)>math.floor(hpMax(u)/2) then u.hp=u.hp-math.floor(hpMax(u)/2); stage(ctx,ctx.user,'attack',6) end; return {} end
    if e=='BATTLE_EFFECT_CURSE' then local types=(ctx.user.mon and ctx.user.mon.types) or ctx.user.types or {}; local ghost=false; for _,t in ipairs(types) do if t=='GHOST' then ghost=true end end; if ghost then hurt(ctx,ctx.user,math.floor(hpMax(monOf(ctx.user))/2)); ctx.target.cursed=true else stage(ctx,ctx.user,'speed',-1); stage(ctx,ctx.user,'attack',1); stage(ctx,ctx.user,'defense',1) end; return {} end

    -- Ability and item manipulation (persistent on mon records in Gen3/4 mode).
    if e=='BATTLE_EFFECT_COPY_ABILITY' then monOf(ctx.user).urAbilityOverride=monOf(ctx.target).urAbilityOverride or ctx.target.urAbility; return {} end
    if e=='BATTLE_EFFECT_SWITCH_ABILITIES' then local a,b=monOf(ctx.user),monOf(ctx.target); a.urAbilityOverride,b.urAbilityOverride=b.urAbilityOverride or b.urAbility,a.urAbilityOverride or a.urAbility; return {} end
    if e=='BATTLE_EFFECT_SUPRESS_ABILITY' then ctx.target.abilitySuppressed=true; return {} end
    if e=='BATTLE_EFFECT_SET_ABILITY_TO_INSOMNIA' then monOf(ctx.target).urAbilityOverride='ABILITY_INSOMNIA'; return {} end
    if e=='BATTLE_EFFECT_SWITCH_HELD_ITEMS' then
      if ta=='ABILITY_STICKY_HOLD' then msg(ctx,'STICKY HOLD kept the item!') else local a,b=monOf(ctx.user),monOf(ctx.target); a.item,b.item=b.item,a.item end; return {}
    end
    if e=='BATTLE_EFFECT_STEAL_HELD_ITEM' then
      if ta=='ABILITY_STICKY_HOLD' then msg(ctx,'STICKY HOLD kept the item!') else local a,b=monOf(ctx.user),monOf(ctx.target); if not a.item and b.item then a.item,b.item=b.item,nil end end; return {}
    end
    if e=='BATTLE_EFFECT_REMOVE_HELD_ITEM' then if ta=='ABILITY_STICKY_HOLD' then msg(ctx,'STICKY HOLD kept the item!') else monOf(ctx.target).item=nil end; return {} end
    if e=='BATTLE_EFFECT_RECYCLE' then local u=monOf(ctx.user); if not u.item and u.urConsumedItem then u.item=u.urConsumedItem; u.urConsumedItem=nil end; return {} end
    if e=='BATTLE_EFFECT_EAT_BERRY' then local t=monOf(ctx.target); if t.item and tostring(t.item):find('BERRY') then t.urConsumedItem=t.item; t.item=nil end; return {} end

    -- Copy/call/transform style effects: Gen1 context can call moves natively;
    -- Gold keeps the request as a volatile that its move-used bridge consumes.
    if e=='BATTLE_EFFECT_CALL_RANDOM_MOVE' or e=='BATTLE_EFFECT_USE_RANDOM_ALLY_MOVE' or e=='BATTLE_EFFECT_USE_RANDOM_LEARNED_MOVE_SLEEP' or e=='BATTLE_EFFECT_NATURE_POWER' then ctx.user.urCallRandomMove=true; return {} end
    if e=='BATTLE_EFFECT_COPY_MOVE' or e=='BATTLE_EFFECT_USE_LAST_USED_MOVE' or e=='BATTLE_EFFECT_COPY_MOVE_FOR_BATTLE' then ctx.user.urCallMove=ctx.target.lastMove; return {} end
    if e=='BATTLE_EFFECT_TRANSFORM' then
      local u,t=monOf(ctx.user),monOf(ctx.target); if u and t then u.urTransformBackup=u.urTransformBackup or {species=u.species,stats=u.stats,moves=u.moves}; u.species=t.species; u.stats=t.stats; u.moves=t.moves end; return {}
    end

    -- Stockpile family.
    if e=='BATTLE_EFFECT_STOCKPILE' then ctx.user.stockpile=math.min(3,(ctx.user.stockpile or 0)+1); return {} end
    if e=='BATTLE_EFFECT_SWALLOW' then local n=ctx.user.stockpile or 0; if n>0 then heal(ctx,ctx.user,math.floor(hpMax(monOf(ctx.user))*({[1]=1/4,[2]=1/2,[3]=1})[n])); ctx.user.stockpile=0 end; return {} end
    if e=='BATTLE_EFFECT_SPIT_UP' then if ctx._gold then local n=ctx.user.stockpile or 0; if n>0 then doGoldDamage(ctx,100*n); ctx.user.stockpile=0 end end; return {} end

    -- Party/status utility.
    if e=='BATTLE_EFFECT_CURE_PARTY_STATUS' then local party=ctx.battle and (monOf(ctx.user)==ctx.battle.player and ctx.battle.party or ctx.battle.enemyParty); for _,x in ipairs(party or {}) do x.status=nil end; return {} end
    if e=='BATTLE_EFFECT_HEAL_STATUS' then monOf(ctx.user).status=nil; return {} end
    if e=='BATTLE_EFFECT_TRANSFER_STATUS' then local u,t=monOf(ctx.user),monOf(ctx.target); if u.status and not t.status then t.status=u.status; u.status=nil end; return {} end
    if e=='BATTLE_EFFECT_AVERAGE_HP' then local u,t=monOf(ctx.user),monOf(ctx.target); local avg=math.floor(((u.hp or 0)+(t.hp or 0))/2); u.hp=math.min(hpMax(u),avg); t.hp=math.min(hpMax(t),avg); return {} end

    -- Switching/fleeing and sacrifice effects.
    if e=='BATTLE_EFFECT_FORCE_SWITCH' then if ta=='ABILITY_SUCTION_CUPS' then msg(ctx,'SUCTION CUPS anchored the target!') else ctx.target.forcedSwitch=true end; return {} end
    if e=='BATTLE_EFFECT_FLEE_FROM_WILD_BATTLE' then if ctx.battle then ctx.battle.over=true; ctx.battle.outcome='fled'; ctx.battle.result='run' end; return {} end
    if e=='BATTLE_EFFECT_FAINT_AND_FULL_HEAL_NEXT_MON' or e=='BATTLE_EFFECT_FAINT_FULL_RESTORE_NEXT_MON' then hurt(ctx,ctx.user,monOf(ctx.user).hp or 1); ctx.user.urHealingWish=true; return {} end
    if e=='BATTLE_EFFECT_FAINT_AND_ATK_SP_ATK_DOWN_2' then stage(ctx,ctx.target,'attack',-2); stage(ctx,ctx.target,'specialAttack',-2); hurt(ctx,ctx.user,monOf(ctx.user).hp or 1); return {} end
    if e=='BATTLE_EFFECT_ALL_FAINT_3_TURNS' then ctx.battle.urPerishSong=3; return {} end
    if e=='BATTLE_EFFECT_KO_MON_THAT_DEFEATED_USER' then ctx.user.destinyBond=true; return {} end

    -- Delayed/charge/repetition markers are driven by shared volatile state;
    -- the move still deals damage on its damaging turn.
    if e=='BATTLE_EFFECT_RECHARGE_AFTER' then ctx.user.rechargeTurns=1; return {} end
    if e=='BATTLE_EFFECT_BIDE' then ctx.user.urBideTurns=2; ctx.user.urBideDamage=0; return {} end
    if e=='BATTLE_EFFECT_UPROAR' then ctx.user.uproarTurns=rand(ctx,2,5); return {} end
    if e=='BATTLE_EFFECT_CONTINUE_AND_CONFUSE_SELF' or e=='BATTLE_EFFECT_DOUBLE_POWER_EACH_TURN_LOCK_INTO' then ctx.user.lockedMove=ctx.moveId; ctx.user.lockedTurns=rand(ctx,2,3); return {} end
    if e=='BATTLE_EFFECT_FLY' or e=='BATTLE_EFFECT_DIG' or e=='BATTLE_EFFECT_DIVE' or e=='BATTLE_EFFECT_BOUNCE' or e=='BATTLE_EFFECT_SHADOW_FORCE' or e:find('CHARGE_TURN') or e=='BATTLE_EFFECT_SKIP_CHARGE_TURN_IN_SUN' then
      if heldEffect(ctx,ctx.user)=='HOLD_EFFECT_CHARGE_SKIP' then consumeHeld(ctx,ctx.user); ctx.user.chargeMove=nil
      else ctx.user.chargeMove=ctx.moveId end
      return {}
    end
    if e=='BATTLE_EFFECT_HIT_IN_3_TURNS' then ctx.user.futureMove={move=ctx.moveId,target=ctx.target,turns=3}; return {} end

    -- Remaining effects are calculation/accuracy/multi-hit/AI or presentation
    -- semantics whose concrete work lives in the damage/turn-order bridge.
    -- Returning {} here is intentional and counted as passive coverage, not an
    -- unknown effect: the source ID remains executable and never downgrades to
    -- NO_ADDITIONAL_EFFECT.
    return {}
  end

  local n,total=0,0
  for e,m in pairs(meta) do
    total=total+1
    local powered=m.powered
    local kind=powered and 'secondary' or 'primary'
    if PRIMARY_POWER[e] then kind='primary' end
    if reg:get(e)==nil then
      local record
      record={kind=kind,run=function(...)
        local ctx=normalized(...)
        return execute(e,ctx,m)
      end}
      reg:register(e,record); n=n+1
    end
  end
  -- Audit classification: every source effect has an actual registry record.
  -- Explicit/passive counts are populated conservatively from named mechanics;
  -- total-registration is the hard gate used by the build validator.
  for e in pairs(meta) do
    if e=='BATTLE_EFFECT_HIT' or e=='BATTLE_EFFECT_DO_NOTHING' or e:find('PRIORITY') or e:find('HIGH_CRITICAL') or e:find('DOUBLE_POWER') or e:find('INCREASE_POWER') or e:find('DECREASE_POWER') or e:find('MULTI_HIT') then passive=passive+1 else explicit=explicit+1 end
  end
  return {registered=n,total=total,explicit=explicit,passive=passive,coverage=total>0 and (explicit+passive)/total or 1}
end
