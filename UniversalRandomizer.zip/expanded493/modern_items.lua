return function(mod, defs, activeGen)
  defs = defs or {}
  local items = mod.content.items
  local registered = 0
  if items then
    for id,d in pairs(defs) do
      if not items:get(id) then
        items:register(id,{id=id,name=d.name,price=math.max(0,d.price or 0),tossable=true})
        registered=registered+1
      end
    end
  end

  local function attach(game)
    if not (game and game.data and game.data.items) then return end
    for id,d in pairs(defs) do
      local r=game.data.items[id]
      if r then
        r.urHoldEffect=d.holdEffect
        r.urHoldParam=d.effectParam or 0
        r.urFlingPower=d.flingPower or 0
        r.urModernHeld=true
      end
    end
  end
  mod.events:on('game.ready',function(ev) attach((ev and ev.game) or mod.game) end)

  local function selectedGen()
    if activeGen then local ok,v=pcall(activeGen); if ok and v then return v end end
    local save=mod.game and mod.game.save; local md=save and save.modData and save.modData.universal_randomizer
    local key=(md and md.committed and md.committed.ruleset) or (md and md.config and md.config.ruleset)
    return tonumber(tostring(key or ''):match('GEN(%d+)'))
  end
  local function enabled() local g=selectedGen(); return g and g>=3 end
  local function holdable(game,id)
    local r=game and game.data and game.data.items and game.data.items[id]
    return r and r.urModernHeld==true
  end
  local function equipMenu(game,mon)
    local ok,ListMenu=pcall(require,'src.ui.ListMenu')
    local okB,Bag=pcall(require,'src.inventory.Bag')
    if not ok or not okB or not game or not game.stack then return end
    local rows={}
    if mon.item then rows[#rows+1]={label='TAKE '..tostring((game.data.items[mon.item] and game.data.items[mon.item].name) or mon.item),value=false} end
    for id,qty in pairs(game.save.inventory or {}) do
      if qty and qty>0 and holdable(game,id) then
        rows[#rows+1]={label=(game.data.items[id].name or id),right='x'..qty,value=id}
      end
    end
    table.sort(rows,function(a,b) return tostring(a.label)<tostring(b.label) end)
    if #rows==0 then rows={{label='NO HOLD ITEMS',value='__NONE'}} end
    local list
    list=ListMenu.new(game,'HELD ITEM',rows,{kind='universal-held-items',onChoose=function(row)
      if not row or row.value=='__NONE' then if list and list.close then list:close() end; return end
      local new=row.value
      local old=mon.item
      if new==false then
        if old then Bag.add(game.save,old,1,game.data); mon.item=nil end
      elseif new then
        if old then Bag.add(game.save,old,1,game.data) end
        if Bag.remove then Bag.remove(game.save,new,1) end
        mon.item=new
      end
      if list and list.close then list:close() end
    end,onCancel=function() if list and list.close then list:close() end end})
    game.stack:push(list)
  end
  mod.hooks:wrap('ui.party.submenu',function(nextFn,game,rows,mon,ctx)
    rows=nextFn(game,rows,mon,ctx)
    if enabled() and type(rows)=='table' and mon then
      rows[#rows+1]={id='universal_held_item',label=mon.item and 'HELD ITEM*' or 'HELD ITEM',onSelect=function(m) equipMenu(game,m or mon) end}
    end
    return rows
  end)

  return {registered=registered,total=(function() local n=0 for _ in pairs(defs) do n=n+1 end return n end)(),defs=defs,attach=attach}
end
