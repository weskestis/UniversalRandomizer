return function(mod, Expansion)
  local M={}

  local PRESETS={
    GEN1={id="ur_gen1",label="GEN 1",gen=1},
    GEN2={id="ur_gen2",label="GEN 2",gen=2},
    GEN3={id="ur_gen3",label="GEN 3",gen=3},
    GEN4={id="ur_gen4",label="GEN 4",gen=4},
  }
  M.PRESETS=PRESETS

  local function copy(t)
    local o={}; for k,v in pairs(t or {}) do o[k]=v end; return o
  end

  -- Gen 1's BattleState consumes these records directly for engine behavior
  -- that already has a ruleset switch. Deeper generation differences are
  -- handled by the shared battle hooks below so Gold receives the same preset.
  local baseGen1={
    oneIn256Miss=true,critUsesBaseSpeed=true,critIgnoresStages=true,
    randMin=217,randMax=255,focusEnergyBug=true,enemyUnlimitedPP=true,
    hyperBeamSkipRechargeOnKO=true,residualAfterMove=true,
  }
  local function engineRecord(key)
    local p=PRESETS[key]
    local r=copy(baseGen1)
    r.name=p.label; r.urGeneration=p.gen
    if p.gen>=2 then
      r.oneIn256Miss=false; r.critIgnoresStages=false; r.focusEnergyBug=false
      r.enemyUnlimitedPP=false; r.hyperBeamSkipRechargeOnKO=false
      r.randMin=217; r.randMax=255; r.residualAfterMove=false
    end
    return r
  end
  if mod.content.rulesets then
    for key,p in pairs(PRESETS) do
      if mod.content.rulesets:get(p.id)==nil then mod.content.rulesets:register(p.id,engineRecord(key)) end
    end
  end

  local function activeCfg()
    if not mod.save:get("seed",nil) then return nil end
    local cfg=mod.save:get("config",nil)
    if type(cfg)~="table" then return nil end
    return cfg
  end
  local function activeKey()
    local cfg=activeCfg(); local k=cfg and cfg.ruleset or nil
    return PRESETS[k] and k or nil
  end
  local function activeGen() local k=activeKey(); return k and PRESETS[k].gen or nil end
  M.activeKey=activeKey; M.activeGeneration=activeGen

  -- Gen 3/4 compatibility traits. Gen1Recomp has no personality value, so a
  -- stable DV/species-derived personality is used; it is deterministic across
  -- save/load and seeds and drives both nature and the two Gen-4 ability slots.
  local NATURES={
    {"HARDY"},{"LONELY","attack","defense"},{"BRAVE","attack","speed"},{"ADAMANT","attack","specialAttack"},{"NAUGHTY","attack","specialDefense"},
    {"BOLD","defense","attack"},{"DOCILE"},{"RELAXED","defense","speed"},{"IMPISH","defense","specialAttack"},{"LAX","defense","specialDefense"},
    {"TIMID","speed","attack"},{"HASTY","speed","defense"},{"SERIOUS"},{"JOLLY","speed","specialAttack"},{"NAIVE","speed","specialDefense"},
    {"MODEST","specialAttack","attack"},{"MILD","specialAttack","defense"},{"QUIET","specialAttack","speed"},{"BASHFUL"},{"RASH","specialAttack","specialDefense"},
    {"CALM","specialDefense","attack"},{"GENTLE","specialDefense","defense"},{"SASSY","specialDefense","speed"},{"CAREFUL","specialDefense","specialAttack"},{"QUIRKY"},
  }
  local function monOf(b) return b and (b.mon or b) end
  local function personality(game,b)
    local m=monOf(b) or {}; local d=m.dvs or {}
    local species=m.species or (b and b.species); local def=species and game and game.data and game.data.pokemon and game.data.pokemon[species]
    local dex=tonumber(def and def.dex) or 0
    local v=(tonumber(d.attack or d.atk) or 0)*4096+(tonumber(d.defense or d.def) or 0)*256+(tonumber(d.speed or d.spd) or 0)*16+(tonumber(d.special or d.sp) or 0)
    return (v*1103515245+dex*12345)%2147483647
  end
  local function randomNaturesEnabled()
    local cfg=activeCfg()
    -- Missing key means an older seeded save; preserve the pre-toggle behavior.
    return cfg==nil or cfg.random_natures~=false
  end
  local function nature(game,b)
    if not randomNaturesEnabled() then return nil end
    return NATURES[(personality(game,b)%25)+1]
  end
  local function natureStat(game,b,stat,value,gen)
    if gen<3 then return value end
    local n=nature(game,b); if not n then return value end
    if n[2]==stat then return math.max(1,math.floor(value*110/100)) end
    if n[3]==stat then return math.max(1,math.floor(value*90/100)) end
    return value
  end
  local function ability(game,b,gen)
    if gen<3 then return nil end
    local m=monOf(b)
    if m and m.urAbilityOverride then return m.urAbilityOverride end
    local species=m and m.species or (b and b.species)
    local def=species and game and game.data and game.data.pokemon and game.data.pokemon[species]
    local a=def and def.urAbilities or nil
    if not a or #a==0 then return nil end
    if #a==1 then return a[1] end
    return a[(personality(game,b)%2)+1] or a[1]
  end
  local function abilityLabel(id)
    local s=tostring(id or ""):gsub("^ABILITY_",""):gsub("_"," ")
    return s:gsub("(%a)([%w']*)",function(a,b) return a:upper()..b:lower() end)
  end
  M.natureFor=function(game,b) local gen=activeGen() or 0; return gen>=3 and nature(game,b) or nil end
  M.natureForGen=function(game,b,gen) return (gen or (activeGen() or 0))>=3 and nature(game,b) or nil end
  M.natureLabel=function(n) return n and tostring(n[1] or n) or nil end
  M.natureStatFor=function(game,b,stat,value,gen) return natureStat(game,b,stat,value,gen or (activeGen() or 0)) end
  M.abilityFor=function(game,b) local gen=activeGen() or 0; return ability(game,b,gen) end
  M.abilityForGen=function(game,b,gen) return ability(game,b,gen or (activeGen() or 0)) end
  M.abilityLabel=abilityLabel
  local function hasAbility(game,b,gen,id) return ability(game,b,gen)==id end
  local function hpThird(b) local m=monOf(b); return m and m.stats and m.hp*3<=m.stats.hp end
  local function moveIsRecoil(move) local e=tostring(move and move.effect or ""); return e:find("RECOIL")~=nil end
  local SOUND_MOVES={UPROAR=true,HYPER_VOICE=true,PERISH_SONG=true,GRASS_WHISTLE=true,BUG_BUZZ=true,CHATTER=true,HEAL_BELL=true,SNORE=true,ROAR=true,SING=true,SUPERSONIC=true,SCREECH=true,METAL_SOUND=true}
  local PUNCH_MOVES={COMET_PUNCH=true,FIRE_PUNCH=true,ICE_PUNCH=true,THUNDER_PUNCH=true,MEGA_PUNCH=true,DIZZY_PUNCH=true,MACH_PUNCH=true,DYNAMIC_PUNCH=true,FOCUS_PUNCH=true,METEOR_MASH=true,SHADOW_PUNCH=true,SKY_UPPERCUT=true,BULLET_PUNCH=true,DRAIN_PUNCH=true,HAMMER_ARM=true}
  local CONTACT_MOVES={AERIAL_ACE=true,AQUA_JET=true,AQUA_TAIL=true,ARM_THRUST=true,ASSURANCE=true,ASTONISH=true,AVALANCHE=true,BIDE=true,BIND=true,BITE=true,BLAZE_KICK=true,BODY_SLAM=true,BOUNCE=true,BRAVE_BIRD=true,BRICK_BREAK=true,BUG_BITE=true,BULLET_PUNCH=true,CLAMP=true,CLOSE_COMBAT=true,COMET_PUNCH=true,CONSTRICT=true,COUNTER=true,COVET=true,CRABHAMMER=true,CROSS_CHOP=true,CROSS_POISON=true,CRUNCH=true,CRUSH_CLAW=true,CRUSH_GRIP=true,CUT=true,DIG=true,DIVE=true,DIZZY_PUNCH=true,DOUBLE_EDGE=true,DOUBLE_HIT=true,DOUBLE_KICK=true,DOUBLE_SLAP=true,DRAGON_CLAW=true,DRAGON_RUSH=true,DRAIN_PUNCH=true,DRILL_PECK=true,DYNAMIC_PUNCH=true,ENDEAVOR=true,EXTREME_SPEED=true,FACADE=true,FAINT_ATTACK=true,FAKE_OUT=true,FALSE_SWIPE=true,FIRE_FANG=true,FIRE_PUNCH=true,FLAIL=true,FLAME_WHEEL=true,FLARE_BLITZ=true,FLY=true,FOCUS_PUNCH=true,FORCE_PALM=true,FRUSTRATION=true,FURY_ATTACK=true,FURY_CUTTER=true,FURY_SWIPES=true,GIGA_IMPACT=true,GRASS_KNOT=true,GUILLOTINE=true,GYRO_BALL=true,HAMMER_ARM=true,HEADBUTT=true,HEAD_SMASH=true,HI_JUMP_KICK=true,HORN_ATTACK=true,HORN_DRILL=true,HYPER_FANG=true,ICE_BALL=true,ICE_FANG=true,ICE_PUNCH=true,IRON_HEAD=true,IRON_TAIL=true,JUMP_KICK=true,KARATE_CHOP=true,KNOCK_OFF=true,LAST_RESORT=true,LEAF_BLADE=true,LEECH_LIFE=true,LICK=true,LOW_KICK=true,MACH_PUNCH=true,MEGAHORN=true,MEGA_KICK=true,MEGA_PUNCH=true,METAL_CLAW=true,METEOR_MASH=true,NEEDLE_ARM=true,NIGHT_SLASH=true,OUTRAGE=true,PAYBACK=true,PECK=true,PETAL_DANCE=true,PLUCK=true,POISON_FANG=true,POISON_JAB=true,POISON_TAIL=true,POUND=true,POWER_WHIP=true,PUNISHMENT=true,PURSUIT=true,QUICK_ATTACK=true,RAGE=true,RAPID_SPIN=true,RETURN=true,REVENGE=true,REVERSAL=true,ROCK_CLIMB=true,ROCK_SMASH=true,ROLLING_KICK=true,ROLLOUT=true,SCRATCH=true,SEISMIC_TOSS=true,SHADOW_CLAW=true,SHADOW_FORCE=true,SHADOW_PUNCH=true,SHADOW_SNEAK=true,SKULL_BASH=true,SKY_UPPERCUT=true,SLAM=true,SLASH=true,SMELLING_SALT=true,SPARK=true,STEEL_WING=true,STOMP=true,STRENGTH=true,STRUGGLE=true,SUBMISSION=true,SUCKER_PUNCH=true,SUPERPOWER=true,SUPER_FANG=true,TACKLE=true,TAKE_DOWN=true,THIEF=true,THRASH=true,THUNDER_FANG=true,THUNDER_PUNCH=true,TRIPLE_KICK=true,TRUMP_CARD=true,U_TURN=true,VICE_GRIP=true,VINE_WHIP=true,VITAL_THROW=true,VOLT_TACKLE=true,WAKE_UP_SLAP=true,WATERFALL=true,WING_ATTACK=true,WOOD_HAMMER=true,WRAP=true,WRING_OUT=true,X_SCISSOR=true,ZEN_HEADBUTT=true}
  local DRAIN_MOVES={ABSORB=true,MEGA_DRAIN=true,GIGA_DRAIN=true,LEECH_LIFE=true,DREAM_EATER=true,DRAIN_PUNCH=true}
  local EXPLOSIVE_MOVES={SELF_DESTRUCT=true,EXPLOSION=true}
  local OHKO_MOVES={GUILLOTINE=true,HORN_DRILL=true,FISSURE=true,SHEER_COLD=true}

  local function hostGen(game)
    return (game and game.data and game.data.gen2Encounters) and 2 or 1
  end
  local function weatherOf(battle)
    if not battle then return nil end
    if battle.field and battle.field.weather then return battle.field.weather end
    local w=battle.weather
    if w=="RAIN" or w=="rain" then return "rain" end
    if w=="SUN" or w=="sun" or w=="SUNNY" then return "sun" end
    if w=="SANDSTORM" or w=="sand" then return "sand" end
    if w=="HAIL" or w=="hail" then return "hail" end
    return w
  end
  local function setWeather(battle,w)
    if not battle then return end
    battle.field=battle.field or {}; battle.field.weather=w
    if battle.weather~=nil then battle.weather=w end
  end

  local function effectiveWeather(game,battle,gen)
    local w=weatherOf(battle)
    if gen and gen>=3 and battle then
      local pa=ability(game,battle.player,gen)
      local ea=ability(game,battle.enemy,gen)
      if pa=="ABILITY_AIR_LOCK" or pa=="ABILITY_CLOUD_NINE" or ea=="ABILITY_AIR_LOCK" or ea=="ABILITY_CLOUD_NINE" then
        return nil
      end
    end
    return w
  end
  M.effectiveWeather=function(game,battle) return effectiveWeather(game,battle,activeGen() or 0) end

  local function heldDef(game,b)
    local m=monOf(b); local id=m and (m.item or m.heldItem)
    if not id then return nil,nil end
    local d=game and game.data and game.data.items and game.data.items[id]
    return d,id
  end
  local function heldEffect(game,b,gen)
    if not gen or gen<3 then return nil,nil,nil end
    if ability(game,b,gen)=="ABILITY_KLUTZ" then return nil,nil,nil end
    local d,id=heldDef(game,b)
    return d and d.urHoldEffect or nil, d and tonumber(d.urHoldParam) or 0, id
  end
  local function consumeHeld(game,b)
    local m=monOf(b); if not m then return nil end
    local id=m.item or m.heldItem
    if not id then return nil end
    m.urConsumedItem=id; m.item=nil; m.heldItem=nil; m.urUnburden=true
    return id
  end
  M.heldEffect=function(game,b) return heldEffect(game,b,activeGen() or 0) end
  M.consumeHeld=function(game,b) return consumeHeld(game,b) end
  local function speciesDex(game,b)
    local m=monOf(b); local id=m and m.species
    local d=id and game and game.data and game.data.pokemon and game.data.pokemon[id]
    return tonumber(d and d.dex) or 0
  end
  local PLATE_TYPES={
    HOLD_EFFECT_ARCEUS_FIRE="FIRE",HOLD_EFFECT_ARCEUS_WATER="WATER",HOLD_EFFECT_ARCEUS_ELECTRIC="ELECTRIC",
    HOLD_EFFECT_ARCEUS_GRASS="GRASS",HOLD_EFFECT_ARCEUS_ICE="ICE",HOLD_EFFECT_ARCEUS_FIGHTING="FIGHTING",
    HOLD_EFFECT_ARCEUS_POISON="POISON",HOLD_EFFECT_ARCEUS_GROUND="GROUND",HOLD_EFFECT_ARCEUS_FLYING="FLYING",
    HOLD_EFFECT_ARCEUS_PSYCHIC="PSYCHIC",HOLD_EFFECT_ARCEUS_BUG="BUG",HOLD_EFFECT_ARCEUS_ROCK="ROCK",
    HOLD_EFFECT_ARCEUS_GHOST="GHOST",HOLD_EFFECT_ARCEUS_DRAGON="DRAGON",HOLD_EFFECT_ARCEUS_DARK="DARK",
    HOLD_EFFECT_ARCEUS_STEEL="STEEL",
  }

  function M.apply(game,cfg)
    cfg=cfg or activeCfg()
    local key=cfg and cfg.ruleset
    local p=PRESETS[key]
    if not (game and p) then return false end
    -- R/B/Y BattleState reads save.options.ruleset when a battle is created.
    -- Gold has no ruleset dispatcher; the same preset is enforced by hooks.
    if hostGen(game)==1 and game.save and game.save.options then
      if mod.save:get("pre_randomizer_ruleset",nil)==nil then
        mod.save:set("pre_randomizer_ruleset",game.save.options.ruleset or "gen1_faithful")
      end
      game.save.options.ruleset=p.id
    end
    return true
  end

  function M.clear(game)
    if game and hostGen(game)==1 and game.save and game.save.options then
      local prior=mod.save:get("pre_randomizer_ruleset",nil)
      if prior then game.save.options.ruleset=prior end
    end
    mod.save:set("pre_randomizer_ruleset",nil)
  end

  -- Platinum source data is authoritative for Gen 1-4 base SpA/SpD and
  -- move categories. It includes all #001-493, even when the host owns the
  -- native definition, so modern rules can split Special without replacing
  -- the cartridge species record.
  local src=Expansion and Expansion.source or {species={},moves={}}
  local speciesByDex={}
  local speciesByNorm={}
  local function norm(s) return tostring(s or ""):upper():gsub("[^A-Z0-9]","") end
  for _,sp in ipairs(src.species or {}) do
    speciesByDex[tonumber(sp.dex)]=sp
    speciesByNorm[norm(sp.id)]=sp; speciesByNorm[norm(sp.name)]=sp
  end
  local moveCategory={}
  for _,mv in ipairs(src.moves or {}) do
    moveCategory[norm(mv.enum)]=mv.category
    moveCategory[norm(mv.name)]=mv.category
  end

  local TYPE_CATEGORY={
    NORMAL="physical",FIGHTING="physical",FLYING="physical",POISON="physical",
    GROUND="physical",ROCK="physical",BUG="physical",GHOST="physical",STEEL="physical",
    FIRE="special",WATER="special",GRASS="special",ELECTRIC="special",
    PSYCHIC="special",PSYCHIC_TYPE="special",ICE="special",DRAGON="special",DARK="special",
  }

  local MODERN_MATCHUPS={
    NORMAL={ROCK=5,GHOST=0,STEEL=5},
    FIRE={FIRE=5,WATER=5,GRASS=20,ICE=20,BUG=20,ROCK=5,DRAGON=5,STEEL=20},
    WATER={FIRE=20,WATER=5,GRASS=5,GROUND=20,ROCK=20,DRAGON=5},
    ELECTRIC={WATER=20,ELECTRIC=5,GRASS=5,GROUND=0,FLYING=20,DRAGON=5},
    GRASS={FIRE=5,WATER=20,GRASS=5,POISON=5,GROUND=20,FLYING=5,BUG=5,ROCK=20,DRAGON=5,STEEL=5},
    ICE={FIRE=5,WATER=5,GRASS=20,ICE=5,GROUND=20,FLYING=20,DRAGON=20,STEEL=5},
    FIGHTING={NORMAL=20,ICE=20,POISON=5,FLYING=5,PSYCHIC=5,PSYCHIC_TYPE=5,BUG=5,ROCK=20,GHOST=0,DARK=20,STEEL=20},
    POISON={GRASS=20,POISON=5,GROUND=5,ROCK=5,GHOST=5,STEEL=0},
    GROUND={FIRE=20,ELECTRIC=20,GRASS=5,POISON=20,FLYING=0,BUG=5,ROCK=20,STEEL=20},
    FLYING={ELECTRIC=5,GRASS=20,FIGHTING=20,BUG=20,ROCK=5,STEEL=5},
    PSYCHIC={FIGHTING=20,POISON=20,PSYCHIC=5,DARK=0,STEEL=5},
    PSYCHIC_TYPE={FIGHTING=20,POISON=20,PSYCHIC_TYPE=5,PSYCHIC=5,DARK=0,STEEL=5},
    BUG={FIRE=5,GRASS=20,FIGHTING=5,POISON=5,FLYING=5,PSYCHIC=20,PSYCHIC_TYPE=20,GHOST=5,DARK=20,STEEL=5},
    ROCK={FIRE=20,ICE=20,FIGHTING=5,GROUND=5,FLYING=20,BUG=20,STEEL=5},
    GHOST={NORMAL=0,PSYCHIC=20,PSYCHIC_TYPE=20,GHOST=20,DARK=5,STEEL=5},
    DRAGON={DRAGON=20,STEEL=5},
    DARK={FIGHTING=5,PSYCHIC=20,PSYCHIC_TYPE=20,GHOST=20,DARK=5,STEEL=5},
    STEEL={FIRE=5,WATER=5,ELECTRIC=5,ICE=20,ROCK=20,STEEL=5},
  }
  -- Gen 1's notable chart differences/bugs. Dark/Steel compatibility rows are
  -- retained so expanded Pokémon remain usable under the faithful preset.
  local GEN1_MATCHUPS=copy(MODERN_MATCHUPS)
  for k,v in pairs(MODERN_MATCHUPS) do GEN1_MATCHUPS[k]=copy(v) end
  GEN1_MATCHUPS.GHOST.PSYCHIC=0; GEN1_MATCHUPS.GHOST.PSYCHIC_TYPE=0
  GEN1_MATCHUPS.BUG.POISON=20
  GEN1_MATCHUPS.POISON.BUG=20
  GEN1_MATCHUPS.ICE.FIRE=10

  local function typeMult(moveType,defTypes,gen)
    local chart=(gen==1) and GEN1_MATCHUPS or MODERN_MATCHUPS
    local row=chart[moveType] or chart[moveType=="PSYCHIC_TYPE" and "PSYCHIC" or moveType] or {}
    local m=10
    for _,t in ipairs(defTypes or {}) do
      local v=row[t]
      if v==nil and t=="PSYCHIC_TYPE" then v=row.PSYCHIC end
      if v~=nil then m=math.floor(m*v/10) end
    end
    return m
  end

  local function stage(v,s)
    s=math.max(-6,math.min(6,tonumber(s) or 0))
    local num,den
    if s>=0 then num=2+s; den=2 else num=2; den=2-s end
    return math.max(1,math.floor((tonumber(v) or 1)*num/den))
  end
  local function accuracyStage(v,s)
    s=math.max(-6,math.min(6,tonumber(s) or 0))
    local num,den
    if s>=0 then num=3+s; den=3 else num=3; den=3-s end
    return math.max(1,math.floor((tonumber(v) or 1)*num/den))
  end

  local function sourceFor(game,b)
    local species=(b and b.mon and b.mon.species) or (b and b.species)
    local def=species and game and game.data and game.data.pokemon and game.data.pokemon[species]
    local dex=def and tonumber(def.dex)
    return (dex and speciesByDex[dex]) or speciesByNorm[norm(species)]
  end
  local function calcOne(base,dv,statExp,level,bonusEV)
    local ev=math.floor(math.min(255,math.ceil(math.sqrt(tonumber(statExp) or 0)))/4)
    -- Gen 3/4 power-item bonus EVs live beside the cartridge's Stat Exp so
    -- modern held-item training can be represented without corrupting the
    -- underlying Gen 1/2 save format. Four EV points equal one stat point
    -- before level scaling, matching the modern formula's floor(EV/4).
    ev=ev+math.floor(math.max(0,tonumber(bonusEV) or 0)/4)
    return math.floor((((tonumber(base) or 1)+(tonumber(dv) or 0))*2+ev)*(tonumber(level) or 1)/100)+5
  end
  local function splitSpecial(game,b,key)
    local sp=sourceFor(game,b)
    local mon=(b and b.mon) or b or {}
    if not sp then
      if b and b.curStats and b.curStats.special then return b.curStats.special end
      if mon.stats then return mon.stats[key] or mon.stats.special or 1 end
      return 1
    end
    local species=(b and b.mon and b.mon.species) or (b and b.species)
    local def=species and game and game.data and game.data.pokemon and game.data.pokemon[species]
    local modern=def and def.urModernBaseStats
    local base=(modern and modern[key]) or ((key=="specialAttack") and sp.stats.spAttack or sp.stats.spDefense)
    local dvs=mon.dvs or {}; local se=mon.statExp or {}
    local dv=dvs.special or dvs.specialAttack or dvs.specialDefense or 0
    return calcOne(base,dv,se.special or se[key] or 0,mon.level or b.level or 1,(mon.urEVs or {})[key])
  end
  local function foldedSpecial(game,b)
    local sp=sourceFor(game,b); local mon=(b and b.mon) or b or {}
    if not sp then
      if b and b.curStats then return b.curStats.special or b.curStats.specialAttack or 1 end
      return mon.stats and (mon.stats.special or mon.stats.specialAttack) or 1
    end
    local species=(b and b.mon and b.mon.species) or (b and b.species)
    local def=species and game and game.data and game.data.pokemon and game.data.pokemon[species]
    local modern=def and def.urModernBaseStats
    local base
    if modern then base=math.floor(((modern.specialAttack or 1)+(modern.specialDefense or 1))/2)
    else base=sp.stats.special or math.floor(((sp.stats.spAttack or 1)+(sp.stats.spDefense or 1))/2) end
    local dvs=mon.dvs or {}; local se=mon.statExp or {}
    return calcOne(base,dvs.special or dvs.specialAttack or 0,se.special or 0,mon.level or b.level or 1,(mon.urEVs or {}).special)
  end
  local function battleStats(game,b,ctxOpts,side,gen,category)
    local statName,value
    if gen==1 and category=="special" then return foldedSpecial(game,b) end
    if category=="special" then statName=side=="attacker" and "specialAttack" or "specialDefense"
    else statName=side=="attacker" and "attack" or "defense" end
    if ctxOpts and ctxOpts[side] then
      local r=ctxOpts[side]; value=r[statName] or (statName=="specialAttack" and r.special) or (statName=="specialDefense" and r.special)
    elseif category=="special" then value=splitSpecial(game,b,statName)
    else local current=b and b.curStats or (b and b.stats) or {}; value=current[statName] or 1 end
    if gen>=3 then
      local mon=monOf(b) or {}; local evs=mon.urEVs or {}; local bonus=tonumber(evs[statName]) or 0
      if bonus>0 then value=(tonumber(value) or 1)+math.floor(math.floor(bonus/4)*(tonumber(mon.level or b.level) or 1)/100) end
    end
    return natureStat(game,b,statName,math.max(1,value or 1),gen)
  end
  local function battlerTypes(game,b)
    local m=monOf(b)
    if m and m.urTypes then return m.urTypes end
    local gen=activeGen() or 0
    if gen>=4 and ability(game,b,gen)=="ABILITY_MULTITYPE" and speciesDex(game,b)==493 then
      local he=heldEffect(game,b,gen)
      local t=PLATE_TYPES[he]
      if t then return {t} end
    end
    if b and b.curTypes then return b.curTypes end
    if b and b.types then return b.types end
    local species=(b and b.mon and b.mon.species) or (b and b.species)
    local d=species and game.data and game.data.pokemon and game.data.pokemon[species]
    return d and d.types or {}
  end
  local function moveCategoryFor(move,gen)
    if not move then return "physical" end
    if move.category=="status" or (tonumber(move.power) or 0)==0 then return "status" end
    if gen>=4 then return moveCategory[norm(move.id)] or moveCategory[norm(move.name)] or move.category or TYPE_CATEGORY[move.type] or "physical" end
    return TYPE_CATEGORY[move.type] or "physical"
  end

  -- Cross-generation RNG adapter. Gen 1 hooks expose a LÖVE-style
  -- rng(lo, hi), while Gen 2 hooks also expose BattleRandom as random(n) ->
  -- 0..n-1. Never probe a one-argument Gen 2 roller with rng(0, max): Lua
  -- silently discards the extra argument and passes n=0, collapsing rolls to
  -- zero (which made Gen 3/4 crit checks fire far too often on G/S/C).
  local function rollByte(rng,max,random)
    max=math.max(0,math.floor(tonumber(max) or 0))
    if type(random)=="function" then
      local ok,v=pcall(random,max+1)
      if ok and type(v)=="number" then
        v=math.floor(v)
        if v<0 then v=0 elseif v>max then v=max end
        return v
      end
    end
    if type(rng)=="function" then
      local ok,v=pcall(rng,0,max)
      if ok and type(v)=="number" then
        v=math.floor(v)
        if v<0 then v=0 elseif v>max then v=max end
        return v
      end
    end
    if love and love.math then return love.math.random(0,max) end
    return math.random(0,max)
  end
  local function critFor(ctx,gen)
    if gen==1 then
      local a=ctx.attacker or ctx.user
      local sp=sourceFor(ctx.battle and ctx.battle.game or mod.game,a)
      local speed=(sp and sp.stats.speed) or (a and a.def and a.def.baseStats and a.def.baseStats.speed) or (a and a.stats and a.stats.speed) or 50
      local b=math.floor(speed/2)
      if a and a.focusEnergy then b=math.floor(b/2) else b=math.min(255,b*2) end
      if ctx.highCrit then b=math.min(255,b*4) else b=math.floor(b/2) end
      return rollByte(ctx.rng,255,ctx.random)<b
    end
    local stageLevel=0
    if gen==2 and ctx.criticalLevel~=nil then stageLevel=ctx.criticalLevel
    else
      local a=ctx.attacker or ctx.user
      local game=(ctx.battle and ctx.battle.game) or mod.game
      local highCrit=ctx.highCrit
      if not highCrit and game and game.data and game.data.moves then
        local mv=game.data.moves[ctx.moveId]
        highCrit=mv and (mv.highCrit or tostring(mv.effect or ""):find("HIGH_CRIT")~=nil) or false
      end
      if highCrit then stageLevel=stageLevel+1 end
      local focused=a and a.focusEnergy
      if not focused and ctx.battle and ctx.battle.volatile and a then
        local ok,v=pcall(ctx.battle.volatile,ctx.battle,a)
        focused=ok and v and v.focusEnergy or false
      end
      if focused then stageLevel=stageLevel+(gen>=3 and 2 or 1) end
    end
    local game=(ctx.battle and ctx.battle.game) or mod.game
    if gen>=3 and ability(game,ctx.attacker or ctx.user,gen)=="ABILITY_SUPER_LUCK" then stageLevel=stageLevel+1 end
    if gen>=3 then
      local b=ctx.attacker or ctx.user
      local he=heldEffect(game,b,gen)
      local dex=speciesDex(game,b)
      if he=="HOLD_EFFECT_CRITRATE_UP" or (he=="HOLD_EFFECT_CHANSEY_CRITRATE_UP" and dex==113) or (he=="HOLD_EFFECT_FARFETCHD_CRITRATE_UP" and dex==83) then stageLevel=stageLevel+1 end
      if he=="HOLD_EFFECT_PINCH_CRITRATE_UP" then local m=monOf(b); local mx=m and m.stats and m.stats.hp or 1; if m and (m.hp or 0)*4<=mx then stageLevel=stageLevel+2 end end
    end
    local den=({[0]=(gen==2 and 15 or 16),[1]=8,[2]=4,[3]=3,[4]=2})[math.min(4,stageLevel)] or 2
    return rollByte(ctx.rng,den-1,ctx.random)==0
  end

  local function battlerName(b)
    local m=monOf(b) or {}
    return m.nickname or m.name or m.species or (b and b.name) or "POKEMON"
  end
  local function announceAbility(battle,b,id,tail)
    if not (battle and id) then return end
    local text=(battlerName(b).."'s "..abilityLabel(id)..(tail or "!"))
    if type(battle.say)=="function" then battle:say(text)
    elseif type(battle.emit)=="function" then battle:emit({kind="message",text=text}) end
  end

  local function healBattler(b,amount)
    local m=monOf(b); if not m then return 0 end
    local maxhp=(m.stats and m.stats.hp) or m.maxHp or 0
    if maxhp<=0 then return 0 end
    local before=m.hp or 0; m.hp=math.min(maxhp,before+math.max(1,math.floor(amount or 0)))
    return m.hp-before
  end
  local function boostStage(b,key,n)
    if not b then return end
    b.stages=b.stages or {}; b.stages[key]=math.max(-6,math.min(6,(b.stages[key] or 0)+(n or 1)))
  end

  local function dynamicMovePower(game,ctx,move,basePower,gen)
    local e=tostring(move and move.effect or "")
    local user,target=ctx.user,ctx.target
    local um,tm=monOf(user) or {},monOf(target) or {}
    local maxU=(um.stats and um.stats.hp) or um.maxHp or math.max(1,um.hp or 1)
    local maxT=(tm.stats and tm.stats.hp) or tm.maxHp or math.max(1,tm.hp or 1)
    local p=math.max(1,tonumber(basePower) or 1)
    if e=="BATTLE_EFFECT_DECREASE_POWER_WITH_LESS_USER_HP" then
      return math.max(1,math.floor(150*math.max(1,um.hp or 1)/math.max(1,maxU)))
    elseif e=="BATTLE_EFFECT_INCREASE_POWER_WITH_LESS_HP" then
      local n=math.floor(48*math.max(1,um.hp or 1)/math.max(1,maxU))
      if n<=1 then return 200 elseif n<=4 then return 150 elseif n<=9 then return 100 elseif n<=16 then return 80 elseif n<=32 then return 40 else return 20 end
    elseif e=="BATTLE_EFFECT_INCREASE_POWER_WITH_MORE_HP" then
      return math.max(1,math.floor(120*math.max(1,tm.hp or 1)/math.max(1,maxT))+1)
    elseif e=="BATTLE_EFFECT_INCREASE_POWER_WITH_MORE_STAT_UP" then
      local total=0
      for _,v in pairs((target and target.stages) or {}) do if type(v)=="number" and v>0 then total=total+v end end
      return math.min(200,60+20*total)
    elseif e=="BATTLE_EFFECT_INCREASE_POWER_WITH_WEIGHT" then
      local dex=speciesDex(game,target); local dm=Expansion and Expansion.dexMeta and Expansion.dexMeta[dex]
      local kg=tonumber(dm and dm.weightKg) or 50
      if kg<10 then return 20 elseif kg<25 then return 40 elseif kg<50 then return 60 elseif kg<100 then return 80 elseif kg<200 then return 100 else return 120 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_AND_CURE_PARALYSIS" then
      local st=tostring(tm.status or ""):lower(); if st:find("para") or st=="par" then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_HEAL_SLEEP" then
      local st=tostring(tm.status or ""):lower(); if st:find("sleep") or st=="slp" then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_IF_HIT" then
      if user and user.urDamagedThisTurn then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_IF_MOVING_SECOND" then
      if target and target.urMovedThisTurn then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_IF_TARGET_HIT" then
      if target and target.urDamagedThisTurn then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_WHEN_BELOW_HALF" then
      if (tm.hp or 0)*2<maxT then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_WHEN_STATUSED" then
      if um.status then return p*2 end
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_EACH_TURN" then
      return math.min(160,p*(2^math.max(0,(user and user.urFuryCutterCount or 1)-1)))
    elseif e=="BATTLE_EFFECT_DOUBLE_POWER_EACH_TURN_LOCK_INTO" then
      return math.min(480,p*(2^math.max(0,(user and user.urRolloutCount or 1)-1)))
    end
    return p
  end

  local function computeDamage(ctx,gen)
    local game=(ctx.battle and ctx.battle.game) or mod.game
    local move=ctx.move or {}
    local category=moveCategoryFor(move,gen)
    if category=="status" or (tonumber(move.power) or 0)<=0 then return 0,{crit=false,critical=false,typeMult=10,effectiveness=10} end
    local user,target=ctx.user,ctx.target
    local uStages=(ctx.opts and ctx.opts.attacker and ctx.opts.attacker.stages) or (user and user.stages) or {}
    local tStages=(ctx.opts and ctx.opts.defender and ctx.opts.defender.stages) or (target and target.stages) or {}
    local atk=battleStats(game,user,ctx.opts,"attacker",gen,category)
    local dfn=battleStats(game,target,ctx.opts,"defender",gen,category)
    local crit=(ctx.opts and ctx.opts.critical)
    if crit==nil then crit=(ctx.opts and ctx.opts.forceCrit); if crit==nil then crit=critFor({battle=ctx.battle,attacker=user,user=user,highCrit=(move.highCrit or tostring(move.effect or ""):find("HIGH_CRITICAL")~=nil),rng=ctx.rng,random=ctx.random},gen) end end
    local atkStage=category=="special" and (uStages.specialAttack or uStages.special or 0) or (uStages.attack or 0)
    local defStage=category=="special" and (tStages.specialDefense or tStages.special or 0) or (tStages.defense or 0)
    local preUa=ability(game,user,gen); local preTa=ability(game,target,gen)
    if preUa=="ABILITY_UNAWARE" then defStage=0 end
    if preTa=="ABILITY_UNAWARE" then atkStage=0 end
    if gen==1 and crit then
      -- Gen 1 crits ignore all stages and double the effective level.
    elseif gen==2 and crit then
      if atkStage<0 then atkStage=0 end; if defStage>0 then defStage=0 end
      atk=stage(atk,atkStage); dfn=stage(dfn,defStage)
    else
      atk=stage(atk,atkStage); dfn=stage(dfn,defStage)
    end
    local mon=(user and user.mon) or user
    if category=="physical" and mon and mon.status=="BRN" and ability(game,user,gen)~="ABILITY_GUTS" then atk=math.max(1,math.floor(atk/2)) end
    if ctx.opts and ctx.opts.screen and not crit then dfn=dfn*2 end
    if (ctx.opts and (ctx.opts.defenseHalved or ctx.opts.explode)) then dfn=math.max(1,math.floor(dfn/2)) end
    local level=(user and (user.level or (user.mon and user.mon.level))) or 1
    local power=tonumber((ctx.opts and ctx.opts.power) or move.power) or 0
    power=dynamicMovePower(game,ctx,move,power,gen)
    local repHe=heldEffect(game,user,gen)
    if repHe=="HOLD_EFFECT_BOOST_REPEATED" and user and user.urRepeatedMoveCount and user.urRepeatedMoveCount>1 then
      power=math.floor(power*math.min(20,10+user.urRepeatedMoveCount-1)/10)
    end
    local ua=ability(game,user,gen); local ta=ability(game,target,gen)
    local moldBreak=(ua=="ABILITY_MOLD_BREAKER")
    -- Lightning Rod / Storm Drain are redirection-only in Gen 3/4, and Plus /
    -- Minus only boost with an allied counterpart. The current RBY/G single
    -- battle hosts have no ally target, so these correctly have no 1v1 modifier.
    local _singleBattleCompatibility=(ua=="ABILITY_LIGHTNING_ROD" or ua=="ABILITY_STORM_DRAIN" or ua=="ABILITY_PLUS" or ua=="ABILITY_MINUS" or ta=="ABILITY_LIGHTNING_ROD" or ta=="ABILITY_STORM_DRAIN")
    local moveId=norm(move.id or move.name)
    if ua=="ABILITY_NORMALIZE" and gen>=4 then move.type="NORMAL" end
    if category=="physical" and ta=="ABILITY_MARVEL_SCALE" then local tm=monOf(target); if tm and tm.status then dfn=math.floor(dfn*3/2) end end
    local the,tparam=heldEffect(game,target,gen)
    local tdex=speciesDex(game,target)
    if category=="special" and tdex==366 and the=="HOLD_EFFECT_CLAMPERL_SPDEF" then dfn=dfn*2 end
    if category=="physical" and tdex==132 and the=="HOLD_EFFECT_DITTO_DEF_UP" then dfn=math.floor(dfn*3/2) end
    if category=="special" and (tdex==380 or tdex==381) and the=="HOLD_EFFECT_LATI_SPECIAL" then dfn=math.floor(dfn*3/2) end
    if crit and (ta=="ABILITY_BATTLE_ARMOR" or ta=="ABILITY_SHELL_ARMOR") and not moldBreak then crit=false end
    -- Offensive Gen 3/4 abilities.
    if category=="physical" and (ua=="ABILITY_HUGE_POWER" or ua=="ABILITY_PURE_POWER") then atk=atk*2 end
    if category=="physical" and ua=="ABILITY_HUSTLE" then atk=math.floor(atk*3/2) end
    if category=="physical" and ua=="ABILITY_GUTS" and mon and mon.status then atk=math.floor(atk*3/2) end
    local he,hp=heldEffect(game,user,gen)
    if category=="physical" and he=="HOLD_EFFECT_CHOICE_ATK" then atk=math.floor(atk*3/2) end
    if category=="special" and he=="HOLD_EFFECT_CHOICE_SPATK" then atk=math.floor(atk*3/2) end
    if category=="special" and speciesDex(game,user)==25 and he=="HOLD_EFFECT_PIKA_SPATK_UP" then atk=atk*2 end
    if category=="physical" and (speciesDex(game,user)==104 or speciesDex(game,user)==105) and he=="HOLD_EFFECT_CUBONE_ATK_UP" then atk=atk*2 end
    if category=="special" and speciesDex(game,user)==366 and he=="HOLD_EFFECT_CLAMPERL_SPATK" then atk=atk*2 end
    if category=="special" and (speciesDex(game,user)==380 or speciesDex(game,user)==381) and he=="HOLD_EFFECT_LATI_SPECIAL" then atk=math.floor(atk*3/2) end
    if ua=="ABILITY_FLOWER_GIFT" and effectiveWeather(game,ctx.battle,gen)=="sun" and category=="physical" then atk=math.floor(atk*3/2) end
    if ta=="ABILITY_FLOWER_GIFT" and effectiveWeather(game,ctx.battle,gen)=="sun" and category=="special" then dfn=math.floor(dfn*3/2) end
    if ua=="ABILITY_TECHNICIAN" and power<=60 then power=math.floor(power*3/2) end
    if ua=="ABILITY_RECKLESS" and moveIsRecoil(move) then power=math.floor(power*6/5) end
    if ua=="ABILITY_IRON_FIST" and PUNCH_MOVES[moveId] then power=math.floor(power*6/5) end
    if mon and mon.urFlashFire and move.type=="FIRE" then power=math.floor(power*3/2) end
    if category=="special" and ua=="ABILITY_SOLAR_POWER" and effectiveWeather(game,ctx.battle,gen)=="sun" then atk=math.floor(atk*3/2) end
    if ua=="ABILITY_RIVALRY" then
      local um,tm=monOf(user) or {},monOf(target) or {}
      if um.gender and tm.gender and um.gender~="N" and tm.gender~="N" then
        if um.gender==tm.gender then power=math.floor(power*5/4) else power=math.max(1,math.floor(power*3/4)) end
      end
    end
    if hpThird(user) then
      if ua=="ABILITY_OVERGROW" and move.type=="GRASS" then power=math.floor(power*3/2)
      elseif ua=="ABILITY_BLAZE" and move.type=="FIRE" then power=math.floor(power*3/2)
      elseif ua=="ABILITY_TORRENT" and move.type=="WATER" then power=math.floor(power*3/2)
      elseif ua=="ABILITY_SWARM" and move.type=="BUG" then power=math.floor(power*3/2) end
    end
    -- Defensive immunities and modifiers available in Gen 3/4.
    if not moldBreak and ta=="ABILITY_LEVITATE" and move.type=="GROUND" then announceAbility(ctx.battle,target,ta," made it immune!"); return 0,{crit=crit,critical=crit,typeMult=0,effectiveness=0,ability=ta} end
    if not moldBreak and ((ta=="ABILITY_FLASH_FIRE" and move.type=="FIRE") or ((ta=="ABILITY_WATER_ABSORB" or ta=="ABILITY_DRY_SKIN") and move.type=="WATER") or ((ta=="ABILITY_VOLT_ABSORB" or ta=="ABILITY_MOTOR_DRIVE") and move.type=="ELECTRIC")) then
      local tm=monOf(target)
      if ta=="ABILITY_FLASH_FIRE" and tm then tm.urFlashFire=true end
      if ta=="ABILITY_WATER_ABSORB" or ta=="ABILITY_VOLT_ABSORB" then if tm and tm.stats then healBattler(target,math.floor(tm.stats.hp/4)) end end
      if ta=="ABILITY_DRY_SKIN" then if tm and tm.stats then healBattler(target,math.floor(tm.stats.hp/4)) end end
      if ta=="ABILITY_MOTOR_DRIVE" then boostStage(target,"speed",1) end
      announceAbility(ctx.battle,target,ta," absorbed the attack!")
      return 0,{crit=crit,critical=crit,typeMult=0,effectiveness=0,ability=ta}
    end
    if not moldBreak and ta=="ABILITY_SOUNDPROOF" and SOUND_MOVES[norm(move.id or move.name)] then announceAbility(ctx.battle,target,ta," blocked the sound!"); return 0,{crit=crit,critical=crit,typeMult=0,effectiveness=0,ability=ta} end
    if ta=="ABILITY_THICK_FAT" and (move.type=="FIRE" or move.type=="ICE") then power=math.max(1,math.floor(power/2)) end
    if ta=="ABILITY_HEATPROOF" and move.type=="FIRE" then power=math.max(1,math.floor(power/2)) end
    if ta=="ABILITY_DRY_SKIN" and move.type=="FIRE" then power=math.floor(power*5/4) end
    local ITEM_TYPE_BOOST={HOLD_EFFECT_STRENGTHEN_NORMAL="NORMAL",HOLD_EFFECT_STRENGTHEN_FIGHT="FIGHTING",HOLD_EFFECT_STRENGTHEN_FLYING="FLYING",HOLD_EFFECT_STRENGTHEN_POISON="POISON",HOLD_EFFECT_STRENGTHEN_GROUND="GROUND",HOLD_EFFECT_STRENGTHEN_ROCK="ROCK",HOLD_EFFECT_STRENGTHEN_BUG="BUG",HOLD_EFFECT_STRENGTHEN_GHOST="GHOST",HOLD_EFFECT_STRENGTHEN_STEEL="STEEL",HOLD_EFFECT_STRENGTHEN_FIRE="FIRE",HOLD_EFFECT_STRENGTHEN_WATER="WATER",HOLD_EFFECT_STRENGTHEN_GRASS="GRASS",HOLD_EFFECT_STRENGTHEN_ELECTRIC="ELECTRIC",HOLD_EFFECT_STRENGTHEN_PSYCHIC="PSYCHIC",HOLD_EFFECT_STRENGTHEN_ICE="ICE",HOLD_EFFECT_STRENGTHEN_DRAGON="DRAGON",HOLD_EFFECT_STRENGTHEN_DARK="DARK"}
    local bt=ITEM_TYPE_BOOST[he] or PLATE_TYPES[he]
    if bt and bt==move.type then power=math.floor(power*(100+(hp>0 and hp or 20))/100) end
    if he=="HOLD_EFFECT_POWER_UP_PHYS" and category=="physical" then power=math.floor(power*11/10) end
    if he=="HOLD_EFFECT_POWER_UP_SPEC" and category=="special" then power=math.floor(power*11/10) end
    local udex=speciesDex(game,user)
    if he=="HOLD_EFFECT_DIALGA_BOOST" and udex==483 and (move.type=="DRAGON" or move.type=="STEEL") then power=math.floor(power*6/5) end
    if he=="HOLD_EFFECT_PALKIA_BOOST" and udex==484 and (move.type=="DRAGON" or move.type=="WATER") then power=math.floor(power*6/5) end
    if he=="HOLD_EFFECT_GIRATINA_BOOST" and udex==487 and (move.type=="DRAGON" or move.type=="GHOST") then power=math.floor(power*6/5) end
    local effectiveLevel=(gen==1 and crit) and math.min(255,level*2) or level
    local dmg=math.floor(math.floor(math.floor((2*effectiveLevel/5)+2)*power*math.max(1,atk)/math.max(1,dfn))/50)+2
    if gen>=2 and crit then dmg=dmg*2; if ua=="ABILITY_SNIPER" then dmg=math.floor(dmg*3/2) end end
    if ctx.opts and ctx.opts.itemBoostPercent and gen>=2 then dmg=math.floor(dmg*(100+ctx.opts.itemBoostPercent)/100) end
    if ctx.opts and ctx.opts.weatherPercent and gen>=2 and ctx.opts.weatherPercent~=10 then dmg=math.max(1,math.floor(dmg*ctx.opts.weatherPercent/10)) end
    local moveType=move.type
    local uTypes=battlerTypes(game,user); local dTypes=battlerTypes(game,target)
    local stab=false; for _,t in ipairs(uTypes) do if t==moveType then stab=true break end end
    if stab then dmg=math.floor(dmg*(ua=="ABILITY_ADAPTABILITY" and 2 or 1.5)) end
    local calcTypes=dTypes
    if ua=="ABILITY_SCRAPPY" and (moveType=="NORMAL" or moveType=="FIGHTING") then
      calcTypes={}; for _,t in ipairs(dTypes) do if t~="GHOST" then calcTypes[#calcTypes+1]=t end end
    end
    local mult=typeMult(moveType,calcTypes,gen)
    if not moldBreak and ta=="ABILITY_WONDER_GUARD" and mult<=10 then announceAbility(ctx.battle,target,ta," blocked the attack!"); return 0,{crit=crit,critical=crit,typeMult=0,effectiveness=0,stab=stab,kind=category,ability=ta} end
    if mult==0 then return 0,{crit=crit,critical=crit,typeMult=0,effectiveness=0,stab=stab,kind=category} end
    if ua=="ABILITY_TINTED_LENS" and mult<10 then mult=mult*2 end
    if he=="HOLD_EFFECT_POWER_UP_SE" and mult>10 then dmg=math.floor(dmg*6/5) end
    if (ta=="ABILITY_FILTER" or ta=="ABILITY_SOLID_ROCK") and mult>10 then mult=math.max(1,math.floor(mult*3/4)) end
    local RESIST_TYPES={HOLD_EFFECT_WEAKEN_NORMAL="NORMAL",HOLD_EFFECT_WEAKEN_SE_FIGHT="FIGHTING",HOLD_EFFECT_WEAKEN_SE_FLYING="FLYING",HOLD_EFFECT_WEAKEN_SE_POISON="POISON",HOLD_EFFECT_WEAKEN_SE_GROUND="GROUND",HOLD_EFFECT_WEAKEN_SE_ROCK="ROCK",HOLD_EFFECT_WEAKEN_SE_BUG="BUG",HOLD_EFFECT_WEAKEN_SE_GHOST="GHOST",HOLD_EFFECT_WEAKEN_SE_STEEL="STEEL",HOLD_EFFECT_WEAKEN_SE_FIRE="FIRE",HOLD_EFFECT_WEAKEN_SE_WATER="WATER",HOLD_EFFECT_WEAKEN_SE_GRASS="GRASS",HOLD_EFFECT_WEAKEN_SE_ELECTRIC="ELECTRIC",HOLD_EFFECT_WEAKEN_SE_PSYCHIC="PSYCHIC",HOLD_EFFECT_WEAKEN_SE_ICE="ICE",HOLD_EFFECT_WEAKEN_SE_DRAGON="DRAGON",HOLD_EFFECT_WEAKEN_SE_DARK="DARK"}
    local rt=RESIST_TYPES[the]
    if rt and rt==moveType and (the=="HOLD_EFFECT_WEAKEN_NORMAL" or mult>10) then
      dmg=math.max(1,math.floor(dmg/2)); consumeHeld(game,target)
    end
    dmg=math.max(1,math.floor(dmg*mult/10))
    if gen==1 then
      local r=217+rollByte(ctx.rng,38,ctx.random); dmg=math.max(1,math.floor(dmg*r/255))
    else
      local r=85+rollByte(ctx.rng,15,ctx.random); dmg=math.max(1,math.floor(dmg*r/100))
    end
    local tm=monOf(target)
    if tm and dmg>=(tm.hp or 0) and (tm.hp or 0)>0 then
      local the=heldEffect(game,target,gen)
      local maxhp=(tm.stats and tm.stats.hp) or tm.maxHp or tm.hp or 1
      if the=="HOLD_EFFECT_ENDURE" and (tm.hp or 0)==maxhp then dmg=math.max(0,(tm.hp or 1)-1); consumeHeld(game,target)
      elseif the=="HOLD_EFFECT_MAYBE_ENDURE" and rollByte(nil,99)<10 then dmg=math.max(0,(tm.hp or 1)-1) end
    end
    local eff=tostring(move.effect or "")
    if tm and eff=="BATTLE_EFFECT_DOUBLE_POWER_AND_CURE_PARALYSIS" and dmg>0 then
      local st=tostring(tm.status or ""):lower(); if st:find("para") or st=="par" then tm.status=nil end
    elseif tm and eff=="BATTLE_EFFECT_DOUBLE_POWER_HEAL_SLEEP" and dmg>0 then
      local st=tostring(tm.status or ""):lower(); if st:find("sleep") or st=="slp" then tm.status=nil end
    end
    return math.min(999,dmg),{crit=crit,critical=crit,typeMult=mult,effectiveness=mult,stab=stab,kind=category}
  end

  mod.hooks:wrap("battle.crit",function(nextFn,ctx)
    local gen=activeGen(); if not gen then return nextFn(ctx) end
    local hg=hostGen((ctx.battle and ctx.battle.game) or mod.game)
    if gen==hg and (gen==1 or gen==2) then return nextFn(ctx) end
    return critFor(ctx,gen)
  end)

  mod.hooks:wrap("battle.accuracy",function(nextFn,ctx)
    local gen=activeGen(); if not gen then return nextFn(ctx) end
    local hg=hostGen((ctx.battle and ctx.battle.game) or mod.game)
    if gen==hg and (gen==1 or gen==2) then return nextFn(ctx) end
    local move=ctx.move
    local gm=(ctx.battle and ctx.battle.game) or mod.game
    if ability(gm,ctx.user,gen)=="ABILITY_TRUANT" and ctx.user and ctx.user.urTruantLoaf then
      announceAbility(ctx.battle,ctx.user,"ABILITY_TRUANT"," is loafing around!")
      return false
    end
    local cmon=monOf(ctx.user)
    local che=heldEffect(gm,ctx.user,gen)
    if cmon and cmon.urChoiceMove and (che=="HOLD_EFFECT_CHOICE_ATK" or che=="HOLD_EFFECT_CHOICE_SPATK" or che=="HOLD_EFFECT_CHOICE_SPEED") and move and (move.id or move.name)~=cmon.urChoiceMove then
      return false
    end
    local acc=tonumber(ctx.accuracy or (move and move.accuracy))
    if not acc or acc<=0 then return true end
    local us=(ctx.user and ctx.user.stages) or {}
    local ts=(ctx.target and ctx.target.stages) or {}
    local game=(ctx.battle and ctx.battle.game) or mod.game
    local preUA=ability(game,ctx.user,gen)
    local accStage=us.accuracy or 0
    if preUA=="ABILITY_KEEN_EYE" and accStage<0 then accStage=0 end
    acc=accuracyStage(acc,accStage)
    acc=math.floor(acc*100/math.max(1,accuracyStage(100,ts.evasion or 0)))
    local ua=ability(game,ctx.user,gen); local ta=ability(game,ctx.target,gen)
    if ua=="ABILITY_COMPOUND_EYES" then acc=math.floor(acc*13/10) end
    if ua=="ABILITY_HUSTLE" and move and moveCategoryFor(move,gen)=="physical" then acc=math.floor(acc*4/5) end
    if ua=="ABILITY_NO_GUARD" or ta=="ABILITY_NO_GUARD" then return true end
    local ew=effectiveWeather(game,ctx.battle,gen)
    if ta=="ABILITY_SAND_VEIL" and ew=="sand" then acc=math.floor(acc*4/5) end
    if ta=="ABILITY_SNOW_CLOAK" and ew=="hail" then acc=math.floor(acc*4/5) end
    if ta=="ABILITY_TANGLED_FEET" and ctx.target and ctx.target.confused then acc=math.floor(acc/2) end
    local the,tp=heldEffect(game,ctx.target,gen)
    if the=="HOLD_EFFECT_ACC_REDUCE" then acc=math.floor(acc*(100-(tp>0 and tp or 10))/100) end
    local uhe,up=heldEffect(game,ctx.user,gen)
    if uhe=="HOLD_EFFECT_ACCURACY_UP" then acc=math.floor(acc*(100+(up>0 and up or 10))/100) end
    if uhe=="HOLD_EFFECT_ACCURACY_UP_SLOWER" and ctx.target and ctx.target.urMovedThisTurn then acc=math.floor(acc*12/10) end
    acc=math.max(1,math.min(100,acc))
    if acc>=100 then return true end
    return rollByte(ctx.rng,99,ctx.random)<acc
  end)

  mod.hooks:wrap("battle.damage",function(nextFn,ctx)
    local gen=activeGen(); if not gen then return nextFn(ctx) end
    -- When the selected preset matches the cartridge generation, defer to the
    -- host's audited native formula. Cross-generation presets use the shared
    -- compatibility calculator below.
    local hg=hostGen((ctx.battle and ctx.battle.game) or mod.game)
    if gen==hg and (gen==1 or gen==2) then return nextFn(ctx) end
    return computeDamage(ctx,gen)
  end)

  mod.hooks:wrap("battle.turn_order",function(nextFn,a,aMove,b,bMove,ctx)
    local gen=activeGen(); if not gen or gen<3 then return nextFn(a,aMove,b,bMove,ctx) end
    local game=(ctx and ctx.battle and ctx.battle.game) or mod.game
    local function pri(m) return tonumber(m and m.priority) or 0 end
    local pa,pb=pri(aMove),pri(bMove); if pa~=pb then return pa>pb end
    if a and a.urItemPriority~=b.urItemPriority then return not not a.urItemPriority end
    local aa,ba=ability(game,a,gen),ability(game,b,gen)
    local ahe=heldEffect(game,a,gen); local bhe=heldEffect(game,b,gen)
    local aLast=(aa=="ABILITY_STALL" or ahe=="HOLD_EFFECT_PRIORITY_DOWN")
    local bLast=(ba=="ABILITY_STALL" or bhe=="HOLD_EFFECT_PRIORITY_DOWN")
    if aLast and not bLast then return false end
    if bLast and not aLast then return true end
    local function speed(x)
      local m=monOf(x); local v=(x and x.curStats and x.curStats.speed) or (m and m.stats and m.stats.speed) or 1
      v=natureStat(game,x,"speed",v,gen); local ab=ability(game,x,gen)
      local w=effectiveWeather(game,ctx and ctx.battle,gen)
      if ab=="ABILITY_SWIFT_SWIM" and w=="rain" then v=v*2 end
      if ab=="ABILITY_CHLOROPHYLL" and w=="sun" then v=v*2 end
      if ab=="ABILITY_QUICK_FEET" and m and m.status then v=math.floor(v*3/2) end
      if ab=="ABILITY_SLOW_START" then v=math.max(1,math.floor(v/2)) end
      if ab=="ABILITY_UNBURDEN" and m and m.urUnburden then v=v*2 end
      local he=heldEffect(game,x,gen)
      if he=="HOLD_EFFECT_CHOICE_SPEED" then v=math.floor(v*3/2) end
      if he=="HOLD_EFFECT_DITTO_SPEED_UP" and speciesDex(game,x)==132 then v=v*2 end
      if he=="HOLD_EFFECT_PRIORITY_DOWN" or he=="HOLD_EFFECT_SPEED_DOWN_GROUNDED" or he=="HOLD_EFFECT_EVS_UP_SPEED_DOWN" then v=math.max(1,math.floor(v/2)) end
      return v
    end
    local sa,sb=speed(a),speed(b)
    local invert=ctx and ctx.battle and ctx.battle.field and ctx.battle.field.trickRoom and ctx.battle.field.trickRoom>0
    if sa~=sb then return invert and sa<sb or sa>sb end
    return nextFn(a,aMove,b,bMove,ctx)
  end)

  mod.events:on("battle.started",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and (ev.battle or ev); if not battle then return end
    local game=battle.game or mod.game
    local function stageDown(target,key)
      if not target then return end
      target.stages=target.stages or {}; target.stages[key]=math.max(-6,(target.stages[key] or 0)-1)
    end
    local function stageUp(target,key)
      if not target then return end
      target.stages=target.stages or {}; target.stages[key]=math.min(6,(target.stages[key] or 0)+1)
    end
    local function entry(user,target)
      if not user then return end
      local ab=ability(game,user,gen)
      if ab=="ABILITY_INTIMIDATE" and target then
        stageDown(target,"attack"); announceAbility(battle,user,ab," cut ATTACK!")
      elseif ab=="ABILITY_DRIZZLE" or ab=="ABILITY_DROUGHT" or ab=="ABILITY_SAND_STREAM" or ab=="ABILITY_SNOW_WARNING" then
        setWeather(battle,(ab=="ABILITY_DRIZZLE" and "rain") or (ab=="ABILITY_DROUGHT" and "sun") or (ab=="ABILITY_SAND_STREAM" and "sand") or "hail")
        announceAbility(battle,user,ab," changed the weather!")
      elseif ab=="ABILITY_TRACE" and target then
        local copied=ability(game,target,gen)
        if copied and copied~="ABILITY_TRACE" then
          local m=monOf(user); if m then m.urAbilityOverride=copied end
          announceAbility(battle,user,"ABILITY_TRACE"," copied "..abilityLabel(copied).."!")
        end
      elseif ab=="ABILITY_DOWNLOAD" and target then
        local tm=monOf(target) or {}; local st=tm.stats or {}
        if (st.defense or 1) <= (st.specialDefense or st.special or 1) then stageUp(user,"attack") else stageUp(user,"specialAttack") end
        announceAbility(battle,user,ab," raised an attacking stat!")
      elseif ab=="ABILITY_FOREWARN" and target then
        announceAbility(battle,user,ab," sensed a dangerous move!")
      elseif ab=="ABILITY_FRISK" and target then
        local tm=monOf(target) or {}; local held=tm.heldItem or tm.item
        if held then announceAbility(battle,user,ab," found "..tostring(held).."!") end
      elseif ab=="ABILITY_PRESSURE" then
        announceAbility(battle,user,ab," is exerting pressure!")
      elseif ab=="ABILITY_AIR_LOCK" or ab=="ABILITY_CLOUD_NINE" then
        announceAbility(battle,user,ab," suppressed weather effects!")
      elseif ab=="ABILITY_ANTICIPATION" and target then
        local scary=false
        local td=monOf(target) or {}
        for _,mi in ipairs(td.moves or target.curMoves or {}) do
          local md=mi and (game.data.moves[mi.id or mi] or mi)
          if md then
            local mt=typeMult(md.type or "NORMAL",battlerTypes(game,user),gen)
            if mt>10 or OHKO_MOVES[norm(md.id or md.name)] then scary=true break end
          end
        end
        if scary then announceAbility(battle,user,ab," shuddered!") end
      elseif ab=="ABILITY_FORECAST" then
        local m=monOf(user)
        if m and speciesDex(game,user)==351 then
          local w=effectiveWeather(game,battle,gen)
          m.urTypes={(w=="sun" and "FIRE") or (w=="rain" and "WATER") or (w=="hail" and "ICE") or "NORMAL"}
          announceAbility(battle,user,ab," changed its type!")
        end
      elseif ab=="ABILITY_SLOW_START" then
        user.urSlowStartTurns=5
        announceAbility(battle,user,ab," is getting its act together!")
      end
    end
    entry(battle.player,battle.enemy); entry(battle.enemy,battle.player)
  end)

  -- Gen 3/4 compatibility mechanics can apply end-of-turn HP changes from
  -- battle.turn_ended (Solar Power, Bad Dreams, Black Sludge-style effects,
  -- etc.). Gen1Recomp 0.2.24 raises that event after Gen 2's native faint
  -- pipeline, so a direct HP drop to zero would otherwise leave the battle UI
  -- offering another command before the engine notices the faint. On Gen 2,
  -- wrap the live battle instance so post-event HP changes are immediately fed
  -- back through the native resolveFaints path, and flush any events produced
  -- by the compatibility listener into the same returned event batch.
  mod.events:on("battle.started",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and (ev.battle or ev); if not battle then return end
    local game=battle.game or mod.game
    if hostGen(game)~=2 or battle.urZeroHpGuardInstalled then return end
    battle.urZeroHpGuardInstalled=true

    if type(battle.canAct)=="function" then
      local baseCanAct=battle.canAct
      battle.canAct=function(self,mon,moveId)
        if mon and (tonumber(mon.hp) or 0)<=0 then return false end
        return baseCanAct(self,mon,moveId)
      end
    end

    if type(battle.takeTurn)=="function" and type(battle.resolveFaints)=="function"
        and type(battle.takeEvents)=="function" then
      local baseTakeTurn=battle.takeTurn
      battle.takeTurn=function(self,action)
        local events=baseTakeTurn(self,action) or {}
        -- battle.turn_ended has now run. If a compatibility effect reduced a
        -- live battler to 0 HP after the host's normal end-of-round faint
        -- check, resolve it before control returns to the battle menu.
        if not self.over and (((self.player and (tonumber(self.player.hp) or 0)<=0)
            or (self.enemy and (tonumber(self.enemy.hp) or 0)<=0))) then
          self:resolveFaints()
        end
        -- turn_ended listeners may also have emitted ability/item messages
        -- after runTurn took its normal event batch. Keep them in this turn
        -- instead of leaking into the next command.
        local extra=self:takeEvents() or {}
        for i=1,#extra do events[#events+1]=extra[i] end
        return events
      end
    end
  end)

  mod.events:on("battle.turn_started",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and (ev.battle or ev); if not battle then return end
    local game=battle.game or mod.game
    local function tick(b)
      if not b then return end
      b.urMovedThisTurn=false; b.urDamagedThisTurn=false; b.urItemPriority=false
      local ab=ability(game,b,gen)
      local he=heldEffect(game,b,gen); local m=monOf(b)
      if he=="HOLD_EFFECT_SOMETIMES_PRIORITY" and rollByte(nil,99)<20 then b.urItemPriority=true end
      if he=="HOLD_EFFECT_PINCH_PRIORITY" and m then
        local mx=(m.stats and m.stats.hp) or m.maxHp or 1
        if (m.hp or 0)*4<=mx then b.urItemPriority=true; consumeHeld(game,b) end
      end
      if ab=="ABILITY_TRUANT" then
        b.urTruantLoaf=not not b.urTruantNext
        b.urTruantNext=not b.urTruantNext
      else b.urTruantLoaf=nil; b.urTruantNext=nil end
      if b.urSlowStartTurns and b.urSlowStartTurns>0 then b.urSlowStartTurns=b.urSlowStartTurns-1 end
    end
    tick(battle.player); tick(battle.enemy)
  end)

  mod.events:on("battle.move_used",function(ev)
    local gen=activeGen(); if not gen or gen<3 or not ev then return end
    local battle,user,target=ev.battle,ev.user,ev.target
    local game=(battle and battle.game) or mod.game
    local um=monOf(user)
    local he=heldEffect(game,user,gen)
    local mid=ev.moveId or (ev.move and ev.move.id)
    if user then
      user.urMovedThisTurn=true
      local eff=tostring(ev.move and ev.move.effect or "")
      if eff=="BATTLE_EFFECT_DOUBLE_POWER_EACH_TURN" then
        if user.urLastMove==mid then user.urFuryCutterCount=math.min(5,(user.urFuryCutterCount or 1)+1) else user.urFuryCutterCount=1 end
      else user.urFuryCutterCount=nil end
      if eff=="BATTLE_EFFECT_DOUBLE_POWER_EACH_TURN_LOCK_INTO" then
        if user.urLastMove==mid then user.urRolloutCount=math.min(5,(user.urRolloutCount or 1)+1) else user.urRolloutCount=1 end
      else user.urRolloutCount=nil end
      if user.urLastMove==mid then user.urRepeatedMoveCount=math.min(11,(user.urRepeatedMoveCount or 1)+1) else user.urRepeatedMoveCount=1 end
      user.urLastMove=mid
    end
    if um and (he=="HOLD_EFFECT_CHOICE_ATK" or he=="HOLD_EFFECT_CHOICE_SPATK" or he=="HOLD_EFFECT_CHOICE_SPEED") and not um.urChoiceMove then
      um.urChoiceMove=mid
    end
    if ability(game,target,gen)~="ABILITY_PRESSURE" or ev.isCalled then return end
    local id=ev.moveId or (ev.move and ev.move.id)
    local function drain(list)
      for _,mi in ipairs(list or {}) do
        if mi and mi.id==id and mi.pp~=nil then mi.pp=math.max(0,mi.pp-1); return true end
      end
    end
    if not drain(user and user.curMoves) then local m=monOf(user); if m then drain(m.moves) end end
    local uhe=heldEffect(game,user,gen)
    if uhe=="HOLD_EFFECT_PP_RESTORE" and um then
      local function restore(list)
        for _,mi in ipairs(list or {}) do
          if mi and mi.id==id and mi.pp~=nil and mi.pp<=0 then mi.pp=math.min(mi.maxPp or mi.maxPP or 99,mi.pp+10); consumeHeld(game,user); return true end
        end
      end
      if not restore(user and user.curMoves) then restore(um.moves) end
    end
  end)

  mod.events:on("battle.damage_dealt",function(ev)
    local gen=activeGen(); if not gen or gen<3 or not ev then return end
    local battle,target,user=ev.battle,ev.target,ev.user
    local game=(battle and battle.game) or mod.game
    local ab=ability(game,target,gen)
    if target and (ev.damage or 0)>0 then target.urDamagedThisTurn=true end
    if ev.crit and ab=="ABILITY_ANGER_POINT" then
      target.stages=target.stages or {}; target.stages.attack=6
      announceAbility(battle,target,ab," maxed ATTACK!")
    end
    if ab=="ABILITY_COLOR_CHANGE" and ev.move and ev.move.type and (ev.damage or 0)>0 then
      local m=monOf(target); if m then m.urTypes={ev.move.type} end
      announceAbility(battle,target,ab," changed its type!")
    end
    local moveId=norm((ev.move and (ev.move.id or ev.move.name)) or ev.moveId)
    local contact=CONTACT_MOVES[moveId] and (ev.damage or 0)>0
    local um,tm=monOf(user),monOf(target)
    local function userDamage(frac)
      if not um then return end
      local max=(um.stats and um.stats.hp) or um.maxHp or 1
      um.hp=math.max(0,(um.hp or 0)-math.max(1,math.floor(max*frac)))
    end
    if contact then
      if ab=="ABILITY_ROUGH_SKIN" then userDamage(1/8); announceAbility(battle,target,ab," hurt the attacker!") end
      local r=rollByte(nil,99)
      if ab=="ABILITY_STATIC" and r<30 and um and not um.status then um.status=(hostGen(game)==1 and "PAR" or "paralyze"); announceAbility(battle,target,ab," paralyzed the attacker!") end
      if ab=="ABILITY_POISON_POINT" and r<30 and um and not um.status then um.status=(hostGen(game)==1 and "PSN" or "poison"); announceAbility(battle,target,ab," poisoned the attacker!") end
      if ab=="ABILITY_FLAME_BODY" and r<30 and um and not um.status then um.status=(hostGen(game)==1 and "BRN" or "burn"); announceAbility(battle,target,ab," burned the attacker!") end
      if ab=="ABILITY_EFFECT_SPORE" and r<30 and um and not um.status then
        local pick=rollByte(nil,2); um.status=(pick==0 and (hostGen(game)==1 and "PAR" or "paralyze")) or (pick==1 and (hostGen(game)==1 and "PSN" or "poison")) or (hostGen(game)==1 and "SLP" or "sleep")
        announceAbility(battle,target,ab," spread spores!")
      end
      if ab=="ABILITY_CUTE_CHARM" and r<30 and user then user.infatuatedWith=target; announceAbility(battle,target,ab," infatuated the attacker!") end
    end
    if tm and (tm.hp or 0)<=0 and ab=="ABILITY_AFTERMATH" and contact then
      userDamage(1/4); announceAbility(battle,target,ab," damaged the attacker!")
    end
    -- Contact/recoil held items.
    local the,tp=heldEffect(game,target,gen)
    if contact and (the=="HOLD_EFFECT_DMG_USER_CONTACT_XFR") then
      userDamage(1/math.max(1,tp>0 and tp or 8))
    end
    if (ev.damage or 0)>0 and um then
      local uhe,up=heldEffect(game,user,gen)
      if uhe=="HOLD_EFFECT_HP_DRAIN_ON_ATK" then
        local max=(um.stats and um.stats.hp) or um.maxHp or 1
        um.hp=math.max(0,(um.hp or 0)-math.max(1,math.floor(max/10)))
      elseif uhe=="HOLD_EFFECT_HP_RESTORE_ON_DMG" then
        healBattler(user,math.max(1,math.floor((ev.damage or 0)/8)))
      elseif uhe=="HOLD_EFFECT_SOMETIMES_FLINCH" and target and rollByte(nil,99)<10 then
        if ability(game,target,gen)~="ABILITY_INNER_FOCUS" then target.flinched=true end
      end
    end
    if (ev.damage or 0)>0 and tm then
      local the=heldEffect(game,target,gen)
      if the=="HOLD_EFFECT_HP_RESTORE_SE" and (ev.typeMult or ev.effectiveness or 10)>10 then
        local max=(tm.stats and tm.stats.hp) or tm.maxHp or 1
        healBattler(target,math.max(1,math.floor(max/4))); consumeHeld(game,target)
      elseif the=="HOLD_EFFECT_RECOIL_PHYSICAL" and (ev.kind=="physical" or (ev.move and moveCategoryFor(ev.move,gen)=="physical")) then
        local max=(um and um.stats and um.stats.hp) or (um and um.maxHp) or 1
        if um then um.hp=math.max(0,(um.hp or 0)-math.max(1,math.floor(max/8))) end; consumeHeld(game,target)
      elseif the=="HOLD_EFFECT_RECOIL_SPECIAL" and (ev.kind=="special" or (ev.move and moveCategoryFor(ev.move,gen)=="special")) then
        local max=(um and um.stats and um.stats.hp) or (um and um.maxHp) or 1
        if um then um.hp=math.max(0,(um.hp or 0)-math.max(1,math.floor(max/8))) end; consumeHeld(game,target)
      end
      if the=="HOLD_EFFECT_SWITCH" and (tm.hp or 0)>0 then target.forcedSwitch=true; consumeHeld(game,target) end
    end
  end)

  mod.events:on("battle.status_inflicted",function(ev)
    local gen=activeGen(); if not gen or gen<3 or not ev then return end
    local battle,target,source=ev.battle,ev.target,ev.source
    local game=(battle and battle.game) or mod.game
    local ab=ability(game,target,gen); local m=monOf(target)
    local st=tostring(ev.status or ""):lower()
    if ab=="ABILITY_EARLY_BIRD" and st:find("sleep") and target then
      target.sleepTurns=math.max(1,math.ceil((target.sleepTurns or 2)/2))
      if m then m.sleepTurns=math.max(1,math.ceil((m.sleepTurns or target.sleepTurns or 2)/2)) end
    end
    local w=effectiveWeather(game,battle,gen)
    local blocked=(ab=="ABILITY_LIMBER" and st:find("para")) or ((ab=="ABILITY_INSOMNIA" or ab=="ABILITY_VITAL_SPIRIT") and st:find("sleep")) or (ab=="ABILITY_IMMUNITY" and (st:find("poison") or st=="psn" or st=="tox")) or (ab=="ABILITY_WATER_VEIL" and (st:find("burn") or st=="brn")) or (ab=="ABILITY_MAGMA_ARMOR" and (st:find("freeze") or st=="frz")) or (ab=="ABILITY_LEAF_GUARD" and w=="sun")
    if blocked and m then
      m.status=nil; announceAbility(battle,target,ab," prevented the status!"); return
    end
    if ab=="ABILITY_SYNCHRONIZE" and source and (st:find("para") or st:find("poison") or st:find("burn") or st=="psn" or st=="tox" or st=="brn" or st=="par") then
      local sm=monOf(source); if sm and not sm.status then sm.status=ev.status; announceAbility(battle,target,ab," shared the status!") end
    end
  end)

  mod.events:on("battle.turn_ended",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and ev.battle or ev; if not battle or battle.over then return end
    local game=battle.game or mod.game; local w=effectiveWeather(game,battle,gen)
    local function each(b)
      if not b then return end
      local m=monOf(b); if not m then return end
      local ab=ability(game,b,gen)
      if ab=="ABILITY_SPEED_BOOST" then b.stages=b.stages or {}; b.stages.speed=math.min(6,(b.stages.speed or 0)+1); announceAbility(battle,b,ab," raised SPEED!") end
      if ab=="ABILITY_SHED_SKIN" and m.status and rollByte(nil,2)==0 then m.status=nil; announceAbility(battle,b,ab," cured its status!") end
      if ab=="ABILITY_HYDRATION" and w=="rain" and m.status then m.status=nil; announceAbility(battle,b,ab," cured its status!") end
      local maxhp=m.stats and m.stats.hp or m.maxHp or 0
      local heal=0
      if ab=="ABILITY_RAIN_DISH" and w=="rain" then heal=math.max(1,math.floor(maxhp/16)) end
      if ab=="ABILITY_ICE_BODY" and w=="hail" then heal=math.max(1,math.floor(maxhp/16)) end
      if ab=="ABILITY_DRY_SKIN" and w=="rain" then heal=math.max(1,math.floor(maxhp/8)) end
      if ab=="ABILITY_POISON_HEAL" and m.status and (tostring(m.status):lower():find("poison") or m.status=="PSN" or m.status=="TOX") then heal=math.max(1,math.floor(maxhp/8)) end
      if heal>0 and maxhp>0 and (m.hp or 0)<maxhp then m.hp=math.min(maxhp,(m.hp or 0)+heal); announceAbility(battle,b,ab," restored HP!") end
      if ab=="ABILITY_SOLAR_POWER" and w=="sun" and maxhp>0 then m.hp=math.max(0,(m.hp or 0)-math.max(1,math.floor(maxhp/8))) end
      if ab=="ABILITY_BAD_DREAMS" then
        local opp=(b==battle.player) and battle.enemy or battle.player; local om=monOf(opp)
        if om and om.status and tostring(om.status):lower():find("sleep") then local oh=om.stats and om.stats.hp or 0; om.hp=math.max(0,(om.hp or 0)-math.max(1,math.floor(oh/8))) end
      end
      -- Gen 3/4 held-item residuals and automatic berries.
      local he,hp,id=heldEffect(game,b,gen)
      if he=="HOLD_EFFECT_HP_RESTORE_GRADUAL" and maxhp>0 then healBattler(b,math.max(1,math.floor(maxhp/16))) end
      if he=="HOLD_EFFECT_HP_RESTORE_PSN_TYPE" and maxhp>0 then
        local poison=false; for _,t in ipairs(battlerTypes(game,b)) do poison=poison or t=="POISON" end
        if poison then healBattler(b,math.max(1,math.floor(maxhp/16)))
        elseif ab~="ABILITY_MAGIC_GUARD" then m.hp=math.max(0,(m.hp or 0)-math.max(1,math.floor(maxhp/8))) end
      end
      if he=="HOLD_EFFECT_BRN_USER" and not m.status then m.status=(hostGen(game)==1 and "BRN" or "burn") end
      if he=="HOLD_EFFECT_PSN_USER" and not m.status then m.status=(hostGen(game)==1 and "PSN" or "poison") end
      local hpNow=m.hp or 0
      if maxhp>0 and hpNow*2<=maxhp and (he=="HOLD_EFFECT_HP_RESTORE" or he=="HOLD_EFFECT_HP_RESTORE_ON_DMG") then
        healBattler(b,he=="HOLD_EFFECT_HP_RESTORE" and (hp>0 and hp or 10) or math.max(1,math.floor(maxhp/8))); consumeHeld(game,b)
      end
      if he=="HOLD_EFFECT_CONFUSE_RESTORE" and b.confused then b.confused=nil; consumeHeld(game,b) end
      if he=="HOLD_EFFECT_HEAL_INFATUATION" and b.infatuatedWith then b.infatuatedWith=nil; consumeHeld(game,b) end
      local pinch=(ab=="ABILITY_GLUTTONY") and 2 or 4
      if maxhp>0 and hpNow*pinch<=maxhp then
        local statByHold={HOLD_EFFECT_PINCH_ATK_UP="attack",HOLD_EFFECT_PINCH_DEF_UP="defense",HOLD_EFFECT_PINCH_SPEED_UP="speed",HOLD_EFFECT_PINCH_SPATK_UP="specialAttack",HOLD_EFFECT_PINCH_SPDEF_UP="specialDefense",HOLD_EFFECT_PINCH_ACC_UP="accuracy"}
        local st=statByHold[he]
        if st then boostStage(b,st,1); consumeHeld(game,b)
        elseif he=="HOLD_EFFECT_PINCH_RANDOM_UP" then
          local opts={"attack","defense","speed","specialAttack","specialDefense"}; boostStage(b,opts[rollByte(nil,#opts-1)+1],2); consumeHeld(game,b)
        elseif he=="HOLD_EFFECT_HP_PCT_RESTORE" or he=="HOLD_EFFECT_HP_RESTORE_BITTER" or he=="HOLD_EFFECT_HP_RESTORE_SPICY" or he=="HOLD_EFFECT_HP_RESTORE_SWEET" or he=="HOLD_EFFECT_HP_RESTORE_SOUR" or he=="HOLD_EFFECT_HP_RESTORE_DRY" then
          healBattler(b,math.max(1,math.floor(maxhp/4))); consumeHeld(game,b)
        end
      end
      -- Ordinary status berries trigger immediately at end of turn.
      local st=tostring(m.status or ""):lower()
      local cure=(he=="HOLD_EFFECT_STATUS_RESTORE" and m.status) or (he=="HOLD_EFFECT_PRZ_RESTORE" and (st:find("para") or st=="par")) or (he=="HOLD_EFFECT_PSN_RESTORE" and st:find("poison")) or (he=="HOLD_EFFECT_BRN_RESTORE" and st:find("burn")) or (he=="HOLD_EFFECT_FRZ_RESTORE" and st:find("freez")) or (he=="HOLD_EFFECT_SLP_RESTORE" and st:find("sleep"))
      if cure then m.status=nil; consumeHeld(game,b) end
    end
    each(battle.player); each(battle.enemy)
  end)

  mod.events:on("battle.battler_switched",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and ev.battle; local b=ev and (ev.battler or ev.mon or ev.incoming)
    local outgoing=ev and ev.outgoing
    local game=(battle and battle.game) or mod.game
    if outgoing then
      local om=monOf(outgoing)
      if ability(game,outgoing,gen)=="ABILITY_NATURAL_CURE" and om then om.status=nil end
      if om then om.urChoiceMove=nil; om.urFlashFire=nil; om.urUnburden=nil end
    end
    if not (battle and b) then return end
    local ab=ability(game,b,gen)
    local target=(b==battle.player) and battle.enemy or battle.player
    if ab=="ABILITY_INTIMIDATE" and target then target.stages=target.stages or {}; target.stages.attack=math.max(-6,(target.stages.attack or 0)-1); announceAbility(battle,b,ab," cut ATTACK!") end
    if ab=="ABILITY_DRIZZLE" or ab=="ABILITY_DROUGHT" or ab=="ABILITY_SAND_STREAM" or ab=="ABILITY_SNOW_WARNING" then
      setWeather(battle,(ab=="ABILITY_DRIZZLE" and "rain") or (ab=="ABILITY_DROUGHT" and "sun") or (ab=="ABILITY_SAND_STREAM" and "sand") or "hail")
      announceAbility(battle,b,ab," changed the weather!")
    end
    if ab=="ABILITY_AIR_LOCK" or ab=="ABILITY_CLOUD_NINE" then announceAbility(battle,b,ab," suppressed weather effects!") end
  end)

  mod.hooks:wrap("battle.run",function(nextFn,ctx)
    local gen=activeGen(); if not gen or gen<3 or not ctx or not ctx.battle then return nextFn(ctx) end
    local battle=ctx.battle; local game=battle.game or mod.game
    local player,enemy=battle.player,battle.enemy
    if ability(game,player,gen)=="ABILITY_RUN_AWAY" then return true end
    local phe=heldEffect(game,player,gen); if phe=="HOLD_EFFECT_FLEE" then return true end
    local ea=ability(game,enemy,gen)
    if ea=="ABILITY_SHADOW_TAG" then return false end
    local ptypes=battlerTypes(game,player)
    local flying=false; local steel=false
    for _,t in ipairs(ptypes) do flying=flying or t=="FLYING"; steel=steel or t=="STEEL" end
    if ea=="ABILITY_ARENA_TRAP" and not flying and ability(game,player,gen)~="ABILITY_LEVITATE" then return false end
    if ea=="ABILITY_MAGNET_PULL" and steel then return false end
    return nextFn(ctx)
  end)

  mod.hooks:wrap("evolution.check",function(nextFn,game,mon,evo,trigger)
    local gen=activeGen(); if not gen or gen<3 then return nextFn(game,mon,evo,trigger) end
    local he=heldEffect(game,mon,gen)
    if he=="HOLD_EFFECT_NO_EVOLVE" then return false end
    return nextFn(game,mon,evo,trigger)
  end)

  -- Gen-4 trade-item evolution effects are consumed by the expanded evolution
  -- adapter using the held item IDs themselves. Keep the effect family named
  -- here as part of the executable compatibility contract rather than leaving
  -- them looking unimplemented in coverage audits.
  local TRADE_EVOLVE_HOLD_EFFECTS={
    HOLD_EFFECT_EVOLVE_DUSCLOPS=true,HOLD_EFFECT_EVOLVE_ELECTABUZZ=true,
    HOLD_EFFECT_EVOLVE_MAGMAR=true,HOLD_EFFECT_EVOLVE_PORYGON=true,
    HOLD_EFFECT_EVOLVE_PORYGON2=true,HOLD_EFFECT_EVOLVE_RHYDON=true,
    HOLD_EFFECT_EVOLVE_SEADRA=true,
  }
  M.tradeEvolutionHoldEffects=TRADE_EVOLVE_HOLD_EFFECTS

  -- Soothe Bell: Gen 3/4 multiplies positive friendship gains by 1.5x. Gold
  -- exposes every native friendship change, so add only the extra half here.
  mod.events:on("happiness.changed",function(ev)
    local gen=activeGen(); if not gen or gen<3 or not ev or not ev.mon then return end
    local game=mod.game; if heldEffect(game,ev.mon,gen)~="HOLD_EFFECT_FRIENDSHIP_UP" then return end
    local d=tonumber(ev.delta) or 0; if d<=0 then return end
    local extra=math.floor(d/2); if extra<=0 then return end
    ev.mon.happiness=math.min(255,(tonumber(ev.mon.happiness) or tonumber(ev.to) or 0)+extra)
  end)

  -- Amulet Coin / Luck Incense. Gold already has a native amuletCoin prize path;
  -- mark it before battle resolution. Gen 1 has no held-item engine, so its
  -- trainer payout is doubled explicitly at battle end.
  mod.events:on("battle.started",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and (ev.battle or ev); local game=(battle and battle.game) or mod.game
    if not (battle and game and game.save) then return end
    local found=false
    for _,m in ipairs(game.save.party or {}) do
      if heldEffect(game,m,gen)=="HOLD_EFFECT_MONEY_UP" then found=true; break end
    end
    battle.urMoneyUp=found
    if found and hostGen(game)==2 then battle.amuletCoin=true end
  end)

  mod.hooks:wrap("battle.exp_award",function(nextFn,ctx)
    nextFn(ctx)
    local gen=activeGen(); local battle=ctx and ctx.battle; local game=(battle and battle.game) or mod.game
    if not gen or gen<3 or not (game and game.save and ctx and ctx.applyShare) then return end
    local participants=math.max(1,tonumber(ctx.participants) or 1)
    local gained={}
    for _,mon in ipairs(ctx.alive or {}) do gained[mon]=true end
    for _,mon in ipairs(game.save.party or {}) do
      if mon and (mon.hp or 0)>0 then
        local he=heldEffect(game,mon,gen)
        if he=="HOLD_EFFECT_EXP_SHARE" then ctx.applyShare(mon,participants*2); gained[mon]=true
        elseif he=="HOLD_EFFECT_EXP_UP" then ctx.applyShare(mon,participants*2); gained[mon]=true end
      end
    end
    -- Power items: +4 EV in their stat for every EXP-bearing KO in Gen 4.
    local powerStat={
      HOLD_EFFECT_LVLUP_HP_EV_UP="hp", HOLD_EFFECT_LVLUP_ATK_EV_UP="attack",
      HOLD_EFFECT_LVLUP_DEF_EV_UP="defense", HOLD_EFFECT_LVLUP_SPEED_EV_UP="speed",
      HOLD_EFFECT_LVLUP_SPATK_EV_UP="specialAttack", HOLD_EFFECT_LVLUP_SPDEF_EV_UP="specialDefense",
    }
    for mon in pairs(gained) do
      local stat=powerStat[heldEffect(game,mon,gen)]
      if stat then
        mon.urEVs=mon.urEVs or {}; local cur=tonumber(mon.urEVs[stat]) or 0
        local total=0; for _,v in pairs(mon.urEVs) do total=total+(tonumber(v) or 0) end
        local room=math.max(0,510-total)
        mon.urEVs[stat]=math.min(255,cur,cur+math.min(4,room))
        -- Correct the accidental min(cur,...) form below in one assignment;
        -- kept separate for Lua 5.1 portability and explicit caps.
        mon.urEVs[stat]=math.min(255,cur+math.min(4,room))
      end
    end
  end)

  mod.hooks:wrap("encounter.roll",function(nextFn,tables,ctx)
    local gen=activeGen(); local game=(ctx and ctx.game) or mod.game
    local enc=nextFn(tables,ctx)
    if not gen or gen<3 or not game then return enc end
    local lead=game.save and game.save.party and game.save.party[1]
    if not lead then return enc end
    local ab=ability(game,lead,gen)
    local he=heldEffect(game,lead,gen)
    if ab=="ABILITY_ILLUMINATE" and not enc then enc=nextFn(tables,ctx) end
    if (ab=="ABILITY_STENCH" or he=="HOLD_EFFECT_ENCOUNTERS_DOWN") and enc and rollByte(nil,1)==0 then return nil end
    return enc
  end)

  -- Gen 4 Pickup/Honey Gather are post-battle field abilities.
  mod.events:on("battle.ended",function(ev)
    local gen=activeGen(); if not gen or gen<3 then return end
    local battle=ev and (ev.battle or ev); local game=(battle and battle.game) or mod.game
    if not (game and game.save and game.save.party) then return end
    if battle and battle.urMoneyUp and hostGen(game)==1 and (ev.result=="win" or ev.outcome=="win" or battle.result=="win") and battle.kind=="trainer" and battle.trainer then
      local foe=battle.enemy and battle.enemy.mon
      local lv=tonumber((foe and foe.level) or (battle.enemy and battle.enemy.level) or 1) or 1
      local bonus=(tonumber(battle.trainer.baseMoney) or 0)*lv
      if bonus>0 then game.save.money=math.min(999999,(tonumber(game.save.money) or 0)+bonus) end
    end
    local okB,Bag=pcall(require,"src.inventory.Bag")
    local function give(id)
      if not id then return end
      if okB and Bag and Bag.add then pcall(Bag.add,game.save,id,1,game.data)
      else game.save.inventory=game.save.inventory or {}; game.save.inventory[id]=(game.save.inventory[id] or 0)+1 end
    end
    local PICKUP={"POTION","ANTIDOTE","SUPER_POTION","GREAT_BALL","REPEL","ESCAPE_ROPE","FULL_HEAL","ULTRA_BALL","HYPER_POTION","RARE_CANDY"}
    for _,m in ipairs(game.save.party) do
      if m and not m.item and not m.heldItem then
        local b={mon=m}; local ab=ability(game,b,gen)
        if ab=="ABILITY_PICKUP" and rollByte(nil,99)<10 then
          local level=tonumber(m.level) or 1
          local tier=math.max(1,math.min(#PICKUP,math.floor(level/10)+1))
          local id=PICKUP[math.max(1,tier-2+rollByte(nil,math.min(2,tier-1)))]
          if game.data.items[id] then m.item=id; m.heldItem=id end
        elseif ab=="ABILITY_HONEY_GATHER" then
          local level=tonumber(m.level) or 1
          local pct=math.min(50,5+math.floor(level/10)*5)
          if rollByte(nil,99)<pct and game.data.items["HONEY"] then m.item="HONEY"; m.heldItem="HONEY" end
        end
      end
    end
  end)


  function M.installAbilityUI(game)
    if M._abilityUIPatched then return true end
    local hg=hostGen(game or mod.game)
    if hg==1 then
      local ok1,S1=pcall(require,table.concat({"src.ui.","Summary","Menu"}))
      if ok1 and S1 and not S1._urAbilityPatched then
        local baseDraw=S1.draw
        S1.draw=function(self,...)
          baseDraw(self,...)
          local gen=activeGen(); if not gen or gen<3 or self.page~=2 then return end
          local id=ability(self.game,self.mon,gen)
          local nat=nature(self.game,self.mon)
          if not id and not nat then return end
          local okF,Font=pcall(require,"src.render.Font"); if not okF then return end
          love.graphics.setColor(0,0,0,1)
          if nat then Font.draw(("N:"..tostring(nat[1] or "")):sub(1,9),0,56) end
          if id then Font.draw(("A:"..abilityLabel(id)):sub(1,10),80,56) end
          love.graphics.setColor(1,1,1,1)
        end
        S1._urAbilityPatched=true
      end
    else
      local ok2,S2=pcall(require,"src.ui.gen2.SummaryMenu")
      if ok2 and S2 and not S2._urAbilityPatched then
        local baseBlue=S2.bluePlacements
        S2.bluePlacements=function(self,...)
          local out=baseBlue(self,...)
          local gen=activeGen(); if not gen or gen<3 then return out end
          local id=ability(self.game,self.mon,gen)
          local nat=nature(self.game,self.mon)
          if nat then out[#out+1]={text=("NAT "..tostring(nat[1] or "")):sub(1,10),x=0,y=14} end
          if id then
            out[#out+1]={text="ABILITY",x=0,y=15}
            out[#out+1]={text=abilityLabel(id):sub(1,10),x=0,y=16}
          end
          return out
        end
        S2._urAbilityPatched=true
      end
    end
    M._abilityUIPatched=true
    return true
  end

  -- The randomizer owns the gameplay ruleset for a seeded save. The ordinary
  -- Options screen may still change presentation/player-preference rows, but
  -- it cannot contradict the seed. Replace the host RULESET row with a locked
  -- read-only row; Gold gets the same row even though vanilla Gold has none.
  mod.hooks:wrap("ui.options.rows",function(nextFn,game,rows)
    rows=nextFn(game,rows)
    local key=activeKey(); if not key or type(rows)~="table" then return rows end
    local label=PRESETS[key].label.." LOCKED"
    local out={}; local inserted=false
    for _,row in ipairs(rows) do
      local id=row.id or row.key
      if id=="ruleset" then
        out[#out+1]={id="ruleset",label="RULESET",value=function() return label end,step=function() return false end,text=function() return label end,cycle=function() end}
        inserted=true
      else out[#out+1]=row end
    end
    if not inserted then
      local pos=math.min(4,#out+1)
      table.insert(out,pos,{id="ruleset",label="RULESET",value=function() return label end,step=function() return false end,text=function() return label end,cycle=function() end,port=true})
    end
    return out
  end)

  return M
end
