return {
  red = {
    generation = 1,
    sha1 = "ea9bcae617fdf159b045185467ae58b2e4a48b9a",
    trade = { nativeCount = 10, allowExtra = true },
    starters = { "BULBASAUR", "CHARMANDER", "SQUIRTLE" },
    runtime = "certifiable",
  },
  blue = {
    generation = 1,
    sha1 = "d7037c83e1ae5b39bde3c30787637ba1d4c48ce2",
    trade = { nativeCount = 10, allowExtra = true },
    starters = { "BULBASAUR", "CHARMANDER", "SQUIRTLE" },
    runtime = "certifiable",
  },
  yellow = {
    generation = 1,
    sha1 = "cc7d03262ebfaf2f06772c1a480c7d9d5f4a38e1",
    trade = { nativeCount = 10, allowExtra = true },
    starters = { "PIKACHU", "EEVEE" },
    runtime = "certifiable",
  },
  gold = {
    generation = 2,
    sha1 = "d8b8a3600a465308c9953dfa04f0081c05bdcb94",
    starters = { "CHIKORITA", "CYNDAQUIL", "TOTODILE" },
    trade = {
      nativeCount = 6,
      allowExtra = true,
      dialogSetCount = 3,
      dialogPointerStride = 6,
      structLength = 32,
      nicknameLength = 11,
      otNameLength = 11,
      dvBytes = 2,
      dialogSets = {
        TRADE_DIALOGSET_COLLECTOR = true,
        TRADE_DIALOGSET_HAPPY = true,
        TRADE_DIALOGSET_NEWBIE = true,
      },
      clearGenderOnRandomize = true,
    },
    runtime = "certifiable",
  },
  silver = {
    generation = 2,
    sha1 = "49b163f7e57702bc939d642a18f591de55d92dae",
    starters = { "CHIKORITA", "CYNDAQUIL", "TOTODILE" },
    -- Retail US Silver uses the same six 32-byte NPC trade rows as Gold.
    trade = {
      nativeCount = 6,
      allowExtra = true,
      dialogSetCount = 3,
      dialogPointerStride = 6,
      structLength = 32,
      nicknameLength = 11,
      otNameLength = 11,
      dvBytes = 2,
      dialogSets = {
        TRADE_DIALOGSET_COLLECTOR = true,
        TRADE_DIALOGSET_HAPPY = true,
        TRADE_DIALOGSET_NEWBIE = true,
      },
      clearGenderOnRandomize = true,
    },
    runtime = "certifiable",
  },
  crystal = {
    generation = 2,
    sha1 = "f2f52230b536214ef7c9924f483392993e226cfb",
    starters = { "CHIKORITA", "CYNDAQUIL", "TOTODILE" },
    -- Crystal adds NPC_TRADE_FOREST (Dugtrio -> Magneton) and the GIRL
    -- dialog set. Keep this here now so future host support cannot silently
    -- truncate Crystal to Gold's six-row table.
    trade = {
      nativeCount = 7,
      allowExtra = true,
      dialogSetCount = 4,
      dialogPointerStride = 8,
      structLength = 32,
      nicknameLength = 11,
      otNameLength = 11,
      dvBytes = 2,
      dialogSets = {
        TRADE_DIALOGSET_COLLECTOR = true,
        TRADE_DIALOGSET_HAPPY = true,
        TRADE_DIALOGSET_NEWBIE = true,
        TRADE_DIALOGSET_GIRL = true,
      },
      clearGenderOnRandomize = true,
    },
    runtime = "pending_gen1recomp",
  },
}
